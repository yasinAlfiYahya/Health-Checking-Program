/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.CekKesehatan;
import com.BeliObat.PembelianObat;
import com.Home.HalamanUtama;
import com.Interface.Interface;
import com.Login.TesterProject;
import com.credit.Credit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static javax.management.Query.match;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * kelas Cek sehat yang meng-extend JFrame dan meng-implements interface Interface
 * @author User
 */
public class CekSehat extends javax.swing.JFrame implements Interface{

    /**
     * untuk menampilkan gui dan sudah termasuk pengecekan tekanan darah, berat badan dan suhu yang akan dimasukan user
     */
    public CekSehat() {
        initComponents();
        periksasistoldandiastol.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textsistol.getText().equals("") || textdiastol.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Harus Diisi" , "Pesan Kesalahan" , JOptionPane.ERROR_MESSAGE);
                }else{
                    try{
                        double sistol = Double.parseDouble(textsistol.getText());
                        double diastol = Double.parseDouble(textdiastol.getText());
                        sistoldastol.setText(String.format("%.1f", sistol) + " / " + String.format("%.1f", diastol));
                        if(Double.parseDouble(textsistol.getText()) < 85 && Double.parseDouble(textdiastol.getText()) < 55){
                            hasil1.setText("Hipotensi");
                            System.out.println(hasil1.getText());
                        }
                        if(Double.parseDouble(textsistol.getText()) >= 85 || Double.parseDouble(textsistol.getText()) < 120  && Double.parseDouble(textdiastol.getText()) >= 55 || Double.parseDouble(textdiastol.getText()) < 80){
                            hasil1.setText("Normal");
                            System.out.println(hasil1.getText());
                        }
                        if(Double.parseDouble(textsistol.getText()) >= 120 || Double.parseDouble(textsistol.getText()) < 140  && Double.parseDouble(textdiastol.getText()) >= 80 || Double.parseDouble(textdiastol.getText()) < 90){
                            hasil1.setText("Prehipertensi");
                            System.out.println(hasil1.getText());
                        }
                        if(Double.parseDouble(textsistol.getText()) >= 140 || Double.parseDouble(textsistol.getText()) < 160  && Double.parseDouble(textdiastol.getText()) >= 90 || Double.parseDouble(textdiastol.getText()) < 100){
                            hasil1.setText("Hipertensi tahap 1");
                            System.out.println(hasil1.getText());
                        }
                        if(Double.parseDouble(textsistol.getText()) >= 160 || Double.parseDouble(textsistol.getText()) < 180  && Double.parseDouble(textdiastol.getText()) >= 100 || Double.parseDouble(textdiastol.getText()) < 110){
                            hasil1.setText("Hipertensi tahap 2");
                            System.out.println(hasil1.getText());
                        }
                        if(Double.parseDouble(textsistol.getText()) >= 180 && Double.parseDouble(textdiastol.getText()) >=  110){
                            hasil1.setText("Krisis hipertensi");
                            System.out.println(hasil1.getText());
                        }
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, "Harus berupa Angka", "Error Message", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        periksaBMI.addActionListener(new ActionListener (){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textbB.getText().equals("") || texttB.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Harus Diisi" , "Pesan Kesalahan" , JOptionPane.ERROR_MESSAGE);
                }else{
                    try{
                        double tinggi = Double.parseDouble(texttB.getText());
                        double berat = Double.parseDouble(textbB.getText());
                        double meter;
                        meter=tinggi/100;
                        double bmi=(float)(berat/(meter*meter));
                        hasilbmi.setText(String.format("%.2f",bmi));
                        if(Double.parseDouble(hasilbmi.getText()) < 18.5){
                            hasil.setText("underweight");
                            System.out.println(hasilbmi.getText());
                        }
                        if(Double.parseDouble(hasilbmi.getText()) >= 18.5 && Double.parseDouble(hasilbmi.getText()) < 25){
                            hasil.setText("normal");
                            System.out.println(hasilbmi.getText());
                        }
                        if(Double.parseDouble(hasilbmi.getText()) >= 25 && Double.parseDouble(hasilbmi.getText()) < 30){
                            hasil.setText("overweight");
                            System.out.println(hasilbmi.getText());
                        }
                        if(Double.parseDouble(hasilbmi.getText()) >= 30 && Double.parseDouble(hasilbmi.getText()) < 35){
                            hasil.setText("obesitas tingkat 1");
                            System.out.println(hasilbmi.getText());
                        }
                        else if(Double.parseDouble(hasilbmi.getText()) >= 35 && Double.parseDouble(hasilbmi.getText()) < 40){
                            hasil.setText("obesitas tingkat 2");
                            System.out.println(hasilbmi.getText());
                        }
                        else if(Double.parseDouble(hasilbmi.getText()) >= 40){
                            hasil.setText("obesitas tingkat 3");
                            System.out.println(hasilbmi.getText());
                        }
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, "Harus berupa Angka", "Error Message", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        
        periksaSuhu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textSuhu.getText().equals("") || textSuhu.getText().charAt(0) == '.'){
                    notice.setText("Harap Masukan Angka");
                    hasilSuhu.setText("");
                }
                else{
                    boolean patokan = true;
                    for(int i = 0; i < textSuhu.getText().length(); i++){
                        if(textSuhu.getText().charAt(i) >= '0' && textSuhu.getText().charAt(i) <= '9' || textSuhu.getText().charAt(i) == '.'){
                            patokan = true;
                        }
                        else {
                            patokan = false;
                            break;
                        }
                    }
                    if(patokan){
                        double suhuNya = Double.parseDouble(textSuhu.getText());
                        if(suhuNya < 36)hasilSuhu.setText("Hasil Suhu Anda Dalam Keadaan Hiportemia");
                        else if(suhuNya >= 36 && suhuNya <= 38)hasilSuhu.setText("Hasil Suhu Anda Dalam Keadaan Normal");
                        else if(suhuNya > 38 && suhuNya <= 40)hasilSuhu.setText("Hasil Suhu Anda Dalam Keadaan Demam");
                        else if(suhuNya > 40)hasilSuhu.setText("Hasil Suhu Anda Dalam Keadaan Hipertemia");
                        notice.setText("");
                    }
                    else{
                        notice.setText("Harap Masukan Angka");
                        hasilSuhu.setText("");
                    }
                }
            }
        });
        
        
        this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
    }

    /**
     *
     * @param u
     * @param p
     */
    public CekSehat(String u, String p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tempU = new javax.swing.JLabel();
        tempPass = new javax.swing.JLabel();
        menuPanelCS = new javax.swing.JPanel();
        sehatPanel = new javax.swing.JPanel();
        bBeratBadan = new javax.swing.JButton();
        bTekananDarah2 = new javax.swing.JButton();
        bSuhu = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        beratBadan = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        hasilbmi = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        periksaBMI = new javax.swing.JButton();
        hasil = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        texttB = new javax.swing.JTextField();
        textbB = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        gambar2 = new javax.swing.JLabel();
        tekananDarah = new javax.swing.JPanel();
        sistoldastol = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        periksasistoldandiastol = new javax.swing.JButton();
        hasil1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        textdiastol = new javax.swing.JTextField();
        textsistol = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        gambar3 = new javax.swing.JLabel();
        suhu = new javax.swing.JPanel();
        notice = new javax.swing.JLabel();
        periksaSuhu = new javax.swing.JButton();
        hasilSuhu = new javax.swing.JLabel();
        textSuhu = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btCekKesehatan = new javax.swing.JButton();
        btBeliObat = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        namaAcc = new javax.swing.JLabel();
        btKeluar = new javax.swing.JButton();
        btCredit = new javax.swing.JButton();
        btHome = new javax.swing.JButton();
        btBiodata = new javax.swing.JButton();

        tempU.setText("jLabel7");

        tempPass.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1321, 685));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuPanelCS.setBackground(new java.awt.Color(255, 255, 255));
        menuPanelCS.setMinimumSize(new java.awt.Dimension(1050, 690));
        menuPanelCS.setPreferredSize(new java.awt.Dimension(1050, 690));
        menuPanelCS.setLayout(new java.awt.CardLayout());

        sehatPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bBeratBadan.setBackground(new java.awt.Color(210, 180, 140));
        bBeratBadan.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        bBeratBadan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/timbangan.png"))); // NOI18N
        bBeratBadan.setText("Berat badan");
        bBeratBadan.setAlignmentY(0.0F);
        bBeratBadan.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bBeratBadan.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        bBeratBadan.setIconTextGap(20);
        bBeratBadan.setMargin(new java.awt.Insets(1, 14, 1, 14));
        bBeratBadan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBeratBadanActionPerformed(evt);
            }
        });
        sehatPanel.add(bBeratBadan, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 360, 270, 60));

        bTekananDarah2.setBackground(new java.awt.Color(210, 180, 140));
        bTekananDarah2.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        bTekananDarah2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/darah.png"))); // NOI18N
        bTekananDarah2.setText("Tekanan Darah");
        bTekananDarah2.setAlignmentY(0.0F);
        bTekananDarah2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bTekananDarah2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        bTekananDarah2.setIconTextGap(20);
        bTekananDarah2.setMargin(new java.awt.Insets(1, 14, 1, 14));
        bTekananDarah2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTekananDarah2ActionPerformed(evt);
            }
        });
        sehatPanel.add(bTekananDarah2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 270, 60));

        bSuhu.setBackground(new java.awt.Color(210, 180, 140));
        bSuhu.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        bSuhu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/termometer.png"))); // NOI18N
        bSuhu.setText("suhu");
        bSuhu.setAlignmentY(0.0F);
        bSuhu.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bSuhu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        bSuhu.setIconTextGap(20);
        bSuhu.setMargin(new java.awt.Insets(1, 14, 1, 14));
        bSuhu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSuhuActionPerformed(evt);
            }
        });
        sehatPanel.add(bSuhu, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 490, 270, 60));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/baground.jpg"))); // NOI18N
        jLabel4.setText("jLabel4");
        sehatPanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        beratBadan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel12.setText("BMI anda         :");
        beratBadan.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 170, 30));

        hasilbmi.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        beratBadan.add(hasilbmi, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 280, 200, 30));

        jLabel13.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        beratBadan.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 140, 210, 20));

        periksaBMI.setText("PERIKSA BMI");
        beratBadan.add(periksaBMI, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 240, -1, -1));

        hasil.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        beratBadan.add(hasil, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 330, 210, 30));

        jLabel14.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel14.setText("Anda termasuk");
        beratBadan.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 330, 150, 30));
        beratBadan.add(texttB, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 180, 210, 30));
        beratBadan.add(textbB, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 110, 210, 30));

        jLabel15.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel15.setText("Tinggi badan (cm)      : ");
        beratBadan.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 260, -1));

        jLabel6.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel6.setText("Berat Badan dan Tinggi Badan");
        beratBadan.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 620, -1));

        jLabel7.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel7.setText("Berat badan (kg)       :");
        beratBadan.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 260, -1));

        gambar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Free UI Design v.1.10.png"))); // NOI18N
        beratBadan.add(gambar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 690));

        sehatPanel.add(beratBadan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        tekananDarah.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sistoldastol.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        tekananDarah.add(sistoldastol, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 290, 160, 30));

        jLabel17.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        tekananDarah.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 140, 210, 20));

        periksasistoldandiastol.setText("PERIKSA SISTOL & DIASTOL");
        tekananDarah.add(periksasistoldandiastol, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 240, -1, -1));

        hasil1.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        tekananDarah.add(hasil1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 290, 210, 30));

        jLabel18.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel18.setText(" mmHg menunjukan ");
        tekananDarah.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 290, 200, 30));
        tekananDarah.add(textdiastol, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 180, 210, 30));
        tekananDarah.add(textsistol, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 110, 210, 30));

        jLabel19.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel19.setText("Diastol                       : ");
        tekananDarah.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 260, -1));

        jLabel8.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel8.setText("Tekanan darah (mmHg): ");
        tekananDarah.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 620, -1));

        jLabel9.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel9.setText("Sistol                         :");
        tekananDarah.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 260, -1));

        gambar3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Free UI Design v.1.10.png"))); // NOI18N
        tekananDarah.add(gambar3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 690));

        sehatPanel.add(tekananDarah, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        suhu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        notice.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        notice.setForeground(new java.awt.Color(255, 0, 51));
        suhu.add(notice, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 120, 340, 30));

        periksaSuhu.setText("PERIKSA SUHU");
        suhu.add(periksaSuhu, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 160, 130, 40));

        hasilSuhu.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        hasilSuhu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        suhu.add(hasilSuhu, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 890, 30));
        suhu.add(textSuhu, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 80, 340, 30));

        jLabel10.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Suhu Tubuh (°C): ");
        suhu.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 620, -1));

        jLabel11.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel11.setText("Suhu (°C)                         :");
        suhu.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 80, 280, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/suhu.png"))); // NOI18N
        suhu.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        sehatPanel.add(suhu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        menuPanelCS.add(sehatPanel, "card4");

        getContentPane().add(menuPanelCS, new org.netbeans.lib.awtextra.AbsoluteConstraints(251, -5, 1070, 690));

        jPanel1.setBackground(new java.awt.Color(153, 255, 204));

        btCekKesehatan.setBackground(new java.awt.Color(153, 255, 204));
        btCekKesehatan.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btCekKesehatan.setText("Cek Kesehatan");
        btCekKesehatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCekKesehatanActionPerformed(evt);
            }
        });

        btBeliObat.setBackground(new java.awt.Color(153, 255, 204));
        btBeliObat.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btBeliObat.setText("Beli Obat");
        btBeliObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBeliObatActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Man.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Sitka Small", 0, 18)); // NOI18N
        jLabel2.setText("WELCOME !");

        namaAcc.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        namaAcc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        namaAcc.setText("Yasin Alfi Yahya");

        btKeluar.setBackground(new java.awt.Color(153, 255, 204));
        btKeluar.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btKeluar.setText("Keluar");
        btKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btKeluarActionPerformed(evt);
            }
        });

        btCredit.setBackground(new java.awt.Color(153, 255, 204));
        btCredit.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btCredit.setText("Credit");
        btCredit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCreditActionPerformed(evt);
            }
        });

        btHome.setBackground(new java.awt.Color(153, 255, 204));
        btHome.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btHome.setText("Home");
        btHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btHomeActionPerformed(evt);
            }
        });

        btBiodata.setBackground(new java.awt.Color(153, 255, 204));
        btBiodata.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btBiodata.setText("Biodata");
        btBiodata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBiodataActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btCekKesehatan, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btBiodata, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btHome, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btBeliObat, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(namaAcc, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel1)
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(namaAcc, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27)
                .addComponent(btHome, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btBeliObat, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btCekKesehatan, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btBiodata, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btBeliObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBeliObatActionPerformed
        // TODO add your handling code here:
        PembelianObat obat = new PembelianObat();
        obat.setVisible(true);
        obat.tempU.setText(tempU.getText());
        obat.tempPass.setText(tempPass.getText());
        obat.namaAcc.setText(namaAcc.getText());
        this.dispose();
    }//GEN-LAST:event_btBeliObatActionPerformed

    private void btKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btKeluarActionPerformed
        int input = JOptionPane.showConfirmDialog(null, "Anda yakin ingin keluar?", "Pesan Konfirmasi", JOptionPane.YES_NO_OPTION);
        if(input == 0){
            TesterProject login = new TesterProject();
            login.setVisible(true);
            login.pack();
            login.setLocationRelativeTo(null);
            login.setDefaultCloseOperation(HalamanUtama.EXIT_ON_CLOSE);
            this.dispose();
        }
    }//GEN-LAST:event_btKeluarActionPerformed

    private void btHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btHomeActionPerformed
        // TODO add your handling code here:
        Interface.setHome(tempU.getText(), tempPass.getText());
        this.dispose();
    }//GEN-LAST:event_btHomeActionPerformed

    private void btBiodataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBiodataActionPerformed
        // TODO add your handling code here:
        Interface.setAbout(tempU.getText(), tempPass.getText());
        this.dispose();
    }//GEN-LAST:event_btBiodataActionPerformed

    private void btCekKesehatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCekKesehatanActionPerformed
        // TODO add your handling code here:
        CekSehat sehat = new CekSehat();
        sehat.setVisible(true);
        sehat.tempU.setText(tempU.getText());
        sehat.tempPass.setText(tempPass.getText());
        sehat.namaAcc.setText(namaAcc.getText());
        this.dispose();
    }//GEN-LAST:event_btCekKesehatanActionPerformed

    private void bBeratBadanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBeratBadanActionPerformed
        // TODO add your handling code here:
        menuPanelCS.removeAll();
//        menuPanel.repaint();
//        menuPanel.revalidate();
        
        menuPanelCS.add(beratBadan);
        menuPanelCS.repaint();
        menuPanelCS.revalidate();
    }//GEN-LAST:event_bBeratBadanActionPerformed

    private void bTekananDarah2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTekananDarah2ActionPerformed
        // TODO add your handling code here:
          menuPanelCS.removeAll();
//        menuPanel.repaint();
//        menuPanel.revalidate();
        
        menuPanelCS.add(tekananDarah);
        menuPanelCS.repaint();
        menuPanelCS.revalidate();
    }//GEN-LAST:event_bTekananDarah2ActionPerformed

    private void bSuhuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSuhuActionPerformed
        // TODO add your handling code here:
        menuPanelCS.removeAll();
//        menuPanel.repaint();
//        menuPanel.revalidate();
        
        menuPanelCS.add(suhu);
        menuPanelCS.repaint();
        menuPanelCS.revalidate();
    }//GEN-LAST:event_bSuhuActionPerformed

    private void btCreditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCreditActionPerformed
        // TODO add your handling code here:
        Credit credit = new Credit();
        credit.setVisible(true);
        credit.tempU.setText(tempU.getText());
        credit.tempPass.setText(tempPass.getText());
        //credit.namaAcc.setText(namaAkun.getText());
        this.dispose();
    }//GEN-LAST:event_btCreditActionPerformed

    /**
     * method utama kelas
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CekSehat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CekSehat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CekSehat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CekSehat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CekSehat().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBeratBadan;
    private javax.swing.JButton bSuhu;
    private javax.swing.JButton bTekananDarah2;
    private javax.swing.JPanel beratBadan;
    private javax.swing.JButton btBeliObat;
    private javax.swing.JButton btBiodata;
    private javax.swing.JButton btCekKesehatan;
    private javax.swing.JButton btCredit;
    private javax.swing.JButton btHome;
    private javax.swing.JButton btKeluar;
    private javax.swing.JLabel gambar2;
    private javax.swing.JLabel gambar3;
    private javax.swing.JLabel hasil;
    private javax.swing.JLabel hasil1;
    private javax.swing.JLabel hasilSuhu;
    private javax.swing.JLabel hasilbmi;
    public javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    public javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel menuPanelCS;
    public javax.swing.JLabel namaAcc;
    private javax.swing.JLabel notice;
    private javax.swing.JButton periksaBMI;
    private javax.swing.JButton periksaSuhu;
    private javax.swing.JButton periksasistoldandiastol;
    private javax.swing.JPanel sehatPanel;
    private javax.swing.JLabel sistoldastol;
    private javax.swing.JPanel suhu;
    private javax.swing.JPanel tekananDarah;
    public javax.swing.JLabel tempPass;
    public javax.swing.JLabel tempU;
    private javax.swing.JTextField textSuhu;
    private javax.swing.JTextField textbB;
    private javax.swing.JTextField textdiastol;
    private javax.swing.JTextField textsistol;
    private javax.swing.JTextField texttB;
    // End of variables declaration//GEN-END:variables
}
