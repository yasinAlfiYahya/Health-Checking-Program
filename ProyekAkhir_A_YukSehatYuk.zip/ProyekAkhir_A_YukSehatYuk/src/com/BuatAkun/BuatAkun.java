package com.BuatAkun;

import com.Interface.Checking;
import java.util.*;
import javax.swing.*;
import java.util.regex.*;
import java.sql.*;
import java.util.logging.*;
import com.Pendaftar.Pendaftar;
import com.Login.TesterProject;

/**
 * kelas Buat Akun meng-extend kelas Pendaftar dan meng-implements interface Checking
 * @author User
 */
public class BuatAkun extends Pendaftar implements Checking{
    Random ran = new Random();

    /**
     * untuk mengumpulkan seluruh akun, bertipe string 
     */
    public HashMap<String, String> akun = new HashMap<>();
    private static final String regexNoHp = "[0-9]{8,13}"; // Regex untuk mengecek inputan no Hp
    private static final String regexPassword = "^[a-zA-Z0-9_!%$]{8,12}"; // Regex untuk mengecek inputan password
    private static final String regexEmail =  "^[\\w]+(.[\\w]+)*@[\\w]+(.com|.co.id)";
    private static final String regexNama = "[a-zA-Z ]+";
    
    /**
     * untuk mengecek password apakah sudah sesuai regex dan sama dengan konfrim password
     * @param pass untuk password yang dimasukan user
     * @return mengembalikan nilai true jika password sudah sesuai regex dan sama dengan konfrim password
     */
    public boolean cekPassword(String pass){
        if(pass.matches(regexPassword)){
            if(pass.equals(konfirmPass.getText())){
                ketPW.setText("");
                return true;
            }else{
                ketPW.setText("Password yang Anda masukkan berbeda!");
                return false;
            }
        }else {
            ketPW.setText("Panjang password harus 8-12 karakter dan tidak boleh terdapat simbol!");
            return false;
        }
        
    }
    
    /**
     * untuk mengecek gender yang di pilih
     * @return mengembalikan sesuai pilihan user
     */
    public String gender(){
        if(jenisKelamin.getSelectedIndex() == 0){
            return "Laki - Laki";
        }else{
            return "Perempuan";
        }
    }
    
    /**
     * untuk mengecek nama apakah sudah sesuai regex
     * @param name untuk nama yang dimasukan user
     * @return mengembalikan true jika nama sudah sesuai regex
     */
    public boolean cekNama(String name){
        if(name.matches(regexNama)){
            return true;
        }else{
            JOptionPane.showMessageDialog(null, "Nama yang dimasukkan harus berupa huruf!", "Warning", JOptionPane.WARNING_MESSAGE);
            return false;
        }
    }
    
    /**
     * untuk mengecek username apakah sudah digunakan
     * @param un untuk username yang dimasukan user
     * @return mengembalikan true jika username belum digunakan
     */
    public boolean cekUsername(String un){
        //String temp = username.getText();
        boolean cek = true;
        
        for(String el : akun.keySet()){
            if(el.equalsIgnoreCase(un)){
                cek = false;
                JOptionPane.showMessageDialog(null, "Username Anda sudah digunakan oleh pengguna lain!", "Warning", JOptionPane.WARNING_MESSAGE);
                break;
            }else{
                cek = true;
            }
        }
        return cek;
    }
    /**
        * untuk mengecek formulir apakah sudah terisi lengkap
        * @return mengembalikan nilai true jika formulir sudah terisi lengkap
    */
    public boolean cekForm(){
        if(password.getText().equals("") || username.getText().equals("") || namaLengkap.getText().equals("") || email.getText().equals("") || nomorHP.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Anda wajib mengisi semua form yang ada!", "Warning", JOptionPane.WARNING_MESSAGE);
            return false;
        }else{
            return true;
        }
    }
    
    /**
     * untuk mengecek nomor hp apakah sudah sesuai regex
     * @param nomor untuk nomor hp yang dimasukan user
     * @return mengembalikan true jika nomor hp sudah sesuai regex
     */
    public boolean cekNomorHp(String nomor){
        if(nomor.matches(regexNoHp)){
            return true;
        }else{
            if(nomorHP.getText().length() < 8 || nomorHP.getText().length() > 13){
                JOptionPane.showMessageDialog(this, "Panjang Nomor HP tidak valid!");
                return false;            
            }else{
                JOptionPane.showMessageDialog(this, "Nomor HP tidak valid!");
                return false;
            }
        }
    }
    
    /**
     * untuk mengecek email apakah sudah sesuai regex
     * @param email untuk email yang dimasukan user
     * @return mengembalikan true jika email sudah sesuai regex
     */
    public boolean cekEmail(String email){
        if(email.matches(regexEmail)){
             return true;
        }else{
            JOptionPane.showMessageDialog(this, "Email invalid! Periksa kembali email Anda.", "Warning", JOptionPane.WARNING_MESSAGE);
            return false;
        }
    }
    
    /**
     * untuk menghapus data yang sudah di isi user
     */
    public void kosongkanText(){
        namaLengkap.setText("");
        nomorHP.setText("");
        email.setText("");
        username.setText("");
        password.setText("");
        konfirmPass.setText("");
    }
    
    /**
     * untuk memberikan hasil generate
     * @return mengembalikan hasil genarate random dari 8 sampai 12 karakter
     */
    public String generate(){
        String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvz0123456789";
        int min = 8;
        int max = 12;
        int length = ran.nextInt(max - min + 1) + min;
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < length; i++){
            sb.append(str.charAt(ran.nextInt(str.length()-1)));
        }
        
        return ""+sb;
    }
    
    // Overloading

    /**
     * untuk memberikan hasil generate yang mempunyai 2 parameter
     * @param min untuk minimal angka
     * @param max untuk maximal angka
     * @return mengembalikan hasil generate dari nama lengkap yang di masukan user di tambah random angka
     */
    public String generate(int min, int max){
        String str = "0123456789";
        String[] token = namaLengkap.getText().split(" ");
        int length = ran.nextInt(max - min + 1) + min;
        StringBuilder sb = new StringBuilder();
        sb.append(token[ran.nextInt(token.length)]);
        for(int i = 0; i < length; i++){
            sb.append(str.charAt(ran.nextInt(str.length()-1)));
        }
        
        return ""+sb;
    }

    /**
     * Creates new form BuatAkun
     */
    public BuatAkun() {
        initComponents();
        koneksi();
        kosongkanText();
        see2.setVisible(false);
        see4.setVisible(false);
        this.setResizable(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        buatAkun = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jenisKelamin = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        namaLengkap = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        nomorHP = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        ketPW = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        konfirmPass = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        see1 = new javax.swing.JLabel();
        see2 = new javax.swing.JLabel();
        see3 = new javax.swing.JLabel();
        see4 = new javax.swing.JLabel();
        btGenerate = new javax.swing.JButton();
        ketUsername = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        jLabel10.setText("jLabel10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buatAkun.setBackground(new java.awt.Color(102, 255, 204));
        buatAkun.setFont(new java.awt.Font("Trajan Pro", 0, 14)); // NOI18N
        buatAkun.setText("Create Account");
        buatAkun.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buatAkun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buatAkunMouseClicked(evt);
            }
        });
        jPanel1.add(buatAkun, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 460, 253, 40));

        jLabel5.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel5.setText("Username: ");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 140, 212, 19));

        jenisKelamin.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jenisKelamin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "                    Laki - Laki", "                   Perempuan" }));
        jenisKelamin.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.add(jenisKelamin, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 244, 40));

        jLabel2.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel2.setText("Nama Lengkap: ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 236, 26));

        jLabel7.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel7.setText("Konfirmasi Password: ");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 330, 253, 20));

        jLabel8.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel8.setText("Jenis Kelamin: ");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 130, -1));

        jLabel3.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel3.setText("Email:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 211, 17));

        jLabel4.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel4.setText("Nomor Handphone:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 212, 22));

        jLabel1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        jLabel1.setText("Lengkapi Profil Anda");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 260, 40));
        jPanel1.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, 260, 33));
        jPanel1.add(namaLengkap, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 244, 35));

        jLabel6.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jLabel6.setText("Password: ");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 220, 176, 20));
        jPanel1.add(nomorHP, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 244, 40));
        jPanel1.add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 244, 34));

        ketPW.setForeground(new java.awt.Color(255, 0, 51));
        jPanel1.add(ketPW, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 410, 410, 40));
        jPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 260, 260, 40));
        jPanel1.add(konfirmPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 360, 260, 40));

        jButton1.setBackground(new java.awt.Color(51, 255, 204));
        jButton1.setFont(new java.awt.Font("Tekton Pro", 0, 14)); // NOI18N
        jButton1.setText("LOGIN");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 0, 70, 40));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel11.setText("Sudah punya akun? ");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, -1, -1));

        see1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/disabled .png"))); // NOI18N
        see1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                see1MouseClicked(evt);
            }
        });
        jPanel1.add(see1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 260, -1, -1));

        see2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/enabled.png"))); // NOI18N
        see2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                see2MouseClicked(evt);
            }
        });
        jPanel1.add(see2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 260, -1, -1));

        see3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/disabled .png"))); // NOI18N
        see3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                see3MouseClicked(evt);
            }
        });
        jPanel1.add(see3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, -1, -1));

        see4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/enabled.png"))); // NOI18N
        see4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                see4MouseClicked(evt);
            }
        });
        jPanel1.add(see4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, -1, -1));

        btGenerate.setText("Generate");
        btGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGenerateActionPerformed(evt);
            }
        });
        jPanel1.add(btGenerate, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 270, 90, -1));

        ketUsername.setForeground(new java.awt.Color(255, 51, 51));
        jPanel1.add(ketUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 510, 400, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 730, 550));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dokter3.jpg"))); // NOI18N
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 0, 410, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void buatAkunMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buatAkunMouseClicked
        // TODO add your handling code here:
        if(cekForm()){
            if(cekNomorHp(nomorHP.getText())){
                if(cekEmail(email.getText())){
                    if(cekNama(namaLengkap.getText())){
                        if(cekPassword(password.getText())){
                            if(cekUsername(username.getText())){
                                try {
                                    stm.executeUpdate("insert into AKUN value ('" + username.getText().toLowerCase() + "','" + namaLengkap.getText() + "','" + email.getText() + "','" + nomorHP.getText()
                                            + "','" + password.getText() + "','" + gender() + "')");
                                    JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan!");
                                    kosongkanText();
                                } catch (Exception ex) {
                                    //ketUsername.setText("You could try username: " + generate(3,4) + ", " + generate(3,5) + ", " + generate(3,6));
                                    JOptionPane.showMessageDialog(this, "Username sudah digunakan oleh pengguna lain!" + 
                                            "\nYou could try username: " + generate(3,4) + ", " + generate(3,5) + ", " + generate(3,6));
                                }
                            }
                        }

                    }
                }
            }
        }
    }//GEN-LAST:event_buatAkunMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        TesterProject masuk = new TesterProject();
        masuk.setVisible(true);
        masuk.pack();
        masuk.setLocationRelativeTo(null);
        masuk.setDefaultCloseOperation(BuatAkun.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void see3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_see3MouseClicked
        // TODO add your handling code here:
        see4.setVisible(true);
        see3.setVisible(false);
        konfirmPass.setEchoChar((char)0);
    }//GEN-LAST:event_see3MouseClicked

    private void see4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_see4MouseClicked
        // TODO add your handling code here:
        see4.setVisible(false);
        see3.setVisible(true);
        konfirmPass.setEchoChar('*');
    }//GEN-LAST:event_see4MouseClicked

    private void btGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGenerateActionPerformed
        // TODO add your handling code here:
        String ran = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvz0123456789";
        password.setText(generate());
    }//GEN-LAST:event_btGenerateActionPerformed

    private void see2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_see2MouseClicked
        // TODO add your handling code here:
        see2.setVisible(false);
        see1.setVisible(true);
        password.setEchoChar('*');
    }//GEN-LAST:event_see2MouseClicked

    private void see1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_see1MouseClicked
        // TODO add your handling code here:
        see2.setVisible(true);
        see1.setVisible(false);
        password.setEchoChar((char)0);
    }//GEN-LAST:event_see1MouseClicked
    
    private void nomorHPKeyTyped(java.awt.event.KeyEvent evt) {                                          
       // allow only numbers
       if(!Character.isDigit(evt.getKeyChar())){
           evt.consume();
       }
    }
    
    /**
     * method utama kelas
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BuatAkun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BuatAkun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BuatAkun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BuatAkun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BuatAkun().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btGenerate;
    private javax.swing.JButton buatAkun;
    private javax.swing.JTextField email;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> jenisKelamin;
    private javax.swing.JLabel ketPW;
    private javax.swing.JLabel ketUsername;
    private javax.swing.JPasswordField konfirmPass;
    private javax.swing.JTextField namaLengkap;
    private javax.swing.JTextField nomorHP;
    private javax.swing.JPasswordField password;
    private javax.swing.JLabel see1;
    private javax.swing.JLabel see2;
    private javax.swing.JLabel see3;
    private javax.swing.JLabel see4;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables

//    public boolean cekEmail(String email) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
}
