package com.Pendaftar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
import com.KoneksiDB.Koneksi;
/**
 * kelas Pendaftar meng-extend Kelas Koneksi
 * @author Asus
 */
public class Pendaftar extends Koneksi{
    private String nama,nomor,email,password,jenisKelamin,username,password2;
   
    /**
     * untuk mengisi username dan password saat construktor dengan dua parameter di panggil
     * @param username untuk mengisi username dari user
     * @param password untuk mengisi password dari user
     */
    public Pendaftar(String username, String password){
       this.username = username;
       this.password = password;
   }
   
    /**
     *untuk mengisi username dan password saat construktor tanpa parameter di panggil
     */
    public Pendaftar(){
       this.username = username;
       this.password = password;
   }
   
    /**
     *untuk mengisi nama, nomor dan email saat construktor dengan tiga parameter di panggil
     * @param nama untuk mengisi nama dari user
     * @param nomor untuk mengisi nomor dari user
     * @param email untuk mengisi email dari user
     */
    public Pendaftar(String nama, String nomor, String email){
       this.nama = nama;
       this.nomor = nomor;
       this.email = email;
   }
    
    /**
     *untuk mengisi username, password, nama, nomor dan email saat construktor dengan lima parameter di panggil
     * @param username untuk mengisi username dari user
     * @param pw untuk mengisi password dari user
     * @param nama untuk mengisi nama dari user
     * @param nomor untuk mengisi nomor dari user
     * @param email untuk mengisi email dari user
     */
    public Pendaftar(String username, String pw, String nama, String nomor, String email){
       this.username = username;
       this.password = pw;
       this.nama = nama;
       this.nomor = nomor;
       this.email = email;
   }
    
    /**
       *untuk mengisi data berupa nama ke dalam objek
       * @param nama untuk memberikan nilai berupa nama ke dalam method setNama()
    */
    public void setNama(String nama){
        this.nama = nama;
    }
    
    /**
     *untuk mengisi data berupa email ke dalam objek
     * @param email untuk memberikan nilai berupa email ke dalam method setEmail()
     */
    public void setEmail(String email){
        this.email = email;
    }
    
    /**
     *untuk mengisi data berupa nomor ke dalam objek
     * @param nomor untuk memberikan nilai berupa nomor ke dalam method setNomor()
     */
    public void setNomor(String nomor){
        this.nomor = nomor;
    }
    
    /**
     *untuk mengisi data berupa jenis kelamin ke dalam objek
     * @param jk untuk memberikan nilai berupa jenis kelamin ke dalam method setJenisKelamin()
     */
    public void setJenisKelamin(String jk){
        this.jenisKelamin = jk;
    }
    
    /**
     *untuk mengisi data berupa username ke dalam objek
     * @param username untuk memberikan nilai berupa username ke dalam method setUsername()
     */
    public void setUsername(String username){
        this.username = username;
    }
    
    /**
     *untuk mengisi data berupa password ke dalam objek
     * @param pw untuk memberikan nilai berupa password ke dalam method setPassword()
     */
    public void setPassword(String pw){
        this.password = pw;
    }
    
    /**
     *untuk mengembalikan data nama berupa string
     * @return mengembalikan nilai String untuk data nama
     */
    public String getNama(){
        return nama;
    }
    
    /**
     *untuk mengembalikan data email berupa string
     * @return mengembalikan nilai String untuk data email
     */
    public String getEmail(){
        return email;
    }
    
    /**
     *untuk mengembalikan data nomor hp berupa string
     * @return mengembalikan nilai String untuk data nomor
     */
    public String getNomorHP(){
        return nomor;
    }
    
    /**
     *untuk mengembalikan data jenis kelamin berupa string
     * @return mengembalikan nilai String untuk data jenis kelamin
     */
    public String getJenisKelamin(){
        return jenisKelamin;
    }
    
    /**
     *untuk mengembalikan data username berupa string
     * @return mengembalikan nilai String untuk data username
     */
    public String getUsername(){
        return username;
    }
    
    /**
     *untuk mengembalikan data password berupa string
     * @return mengembalikan nilai String untuk data password
     */
    public String getPassword(){
        return password;
    }
}
