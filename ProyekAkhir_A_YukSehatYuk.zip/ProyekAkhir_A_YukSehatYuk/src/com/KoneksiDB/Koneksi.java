package com.KoneksiDB;

import java.sql.*;
import javax.swing.JOptionPane;
 
/**
 * Kelas Koneksi
 * @author User
 */
public class Koneksi extends javax.swing.JFrame{

    /**
     * inisialisasi variabel con
     */
    public Connection con;

    /**
     * inisialisasi variabel static koneksi 
     */
    public static Connection koneksi;

    /**
     * inisialisasi variabel stm
     */
    public Statement stm;

    /**
     * inisialisasi dan deklar variabel rs dengan null
     */
    public ResultSet rs = null;

    /**
     * inisialisasi dan deklar variabel pst dengan null
     */
    public PreparedStatement pst = null;
    
    /**
     * untuk mengoneksikan dengan database
     * @return mengembalikan data conection yang ada di database
     */
    public static Connection getKoneksi(){
        if(koneksi == null){
            try {
                String url ="jdbc:mysql://localhost:3306/PENDAFTAR";
                String user="root";
                String pass="";
                Class.forName("com.mysql.cj.jdbc.Driver");
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                koneksi = DriverManager.getConnection(url,user,pass);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Gagal terhubung ke database! ", "Pesan Error!", JOptionPane.ERROR_MESSAGE);
                JOptionPane.showMessageDialog(null, "Koneksi Gagal! " + e.getMessage(), "Pesan Error!", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        return koneksi;
    }
    
    static Object getConnection(){
        throw new UnsupportedOperationException("Gagal Mengimplementasi");
    }
    
    /**
     * untuk untuk mengoneksikan dengan database
     */
    public void koneksi(){
        try {
            String url ="jdbc:mysql://localhost:3306/PENDAFTAR";
            String user="root";
            String pass="";
            Class.forName("com.mysql.cj.jdbc.Driver");
            con =DriverManager.getConnection(url,user,pass);
            stm = con.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Koneksi Gagal");
        }
    }
    
}