package com.BeliObat;
import com.CekKesehatan.CekSehat;
import com.Home.*;
import com.Interface.Interface;
import static com.Interface.Interface.connect;
import com.Interface.JumlahPembelian;
import com.KoneksiDB.Koneksi;
import static com.KoneksiDB.Koneksi.getKoneksi;
import com.Login.TesterProject;
import com.Pendaftar.Pendaftar;
import com.credit.Credit;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 * Kelas Pembelian Obat yang meng-extend JFrame dan meng-implements interface Interface dan interface Jumlah Pembelian
 * @author User
 */
public class PembelianObat extends javax.swing.JFrame implements Interface,JumlahPembelian{
    private ArrayList<Obat> obatDibeli= new ArrayList<Obat>(); 
    Koneksi connect = new Koneksi();
    JTextField[] tx; // textField banyak pembelian
    
    /**
     * menampilkan gui 
     */
    public PembelianObat() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        connect.koneksi();
        setKeranjang();
    }
    
    /**
     * untuk mengecek stok obat di database 
     */
    public void belanjaObat(){    
        for(int i = 0; i < banyakBarang.size(); i++){
            String sql = "SELECT * from OBAT WHERE NAMAOBAT=?";
            connect.con = getKoneksi();

            try{
                connect.pst = connect.con.prepareStatement(sql);
                connect.pst.setString(1, obat.get(i).getText());
                connect.rs = connect.pst.executeQuery();

                if(connect.rs.next()){
                    String namaObat = obat.get(i).getText() + " ";
                    String beratObat = connect.rs.getString("BERAT");
                    String jenisObat = connect.rs.getString("JENISOBAT");
                    int jumlah = Integer.parseInt(banyakBarang.get(i).getText());
                    int stok = connect.rs.getInt("STOK");
                    int tempHarga = connect.rs.getInt("HARGA");
                    if(Integer.parseInt(banyakBarang.get(i).getText()) > 0){
                        if(jumlah <= stok){
                            if(connect.rs.getString("ID_BAGIANPENYAKIT").equals("1"))
                                obatDibeli.add(new ObatKepala(namaObat, jenisObat, jumlah, tempHarga, 11)); // Upcasting
                            else if(connect.rs.getString("ID_BAGIANPENYAKIT").equals("2"))
                                obatDibeli.add(new ObatMata(namaObat, jenisObat, jumlah, tempHarga));
                            else if(connect.rs.getString("ID_BAGIANPENYAKIT").equals("3"))
                                obatDibeli.add(new ObatKaki(namaObat, jenisObat, jumlah, tempHarga));// Upcasting
                            else if(connect.rs.getString("ID_BAGIANPENYAKIT").equals("4"))
                                obatDibeli.add(new ObatMulut(namaObat, jenisObat, jumlah, tempHarga)); // Upcasting
                        }else{
                            JOptionPane.showMessageDialog(null, "Obat " + namaObat + " yang Anda pesan melebihi stok kami"
                                                           + "\nStok Obat " + namaObat + " di toko kami hanya " + stok);
                        }
                    }
                    
                }
            }catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }
    }
    
    /**
     * untuk memasukan data pembelian user ke database
     */
    public void setKeranjang(){
        JLabel[] lbl; // Nama Obat
        JButton[] btP;// Button Plus
        
        JButton[] btM; // Button minus
        lbl = new JLabel[]{ 
            panadolHijau,panadolBiru,panadolMerah,bodrexExtra,paramex,panadolAnak,saridon,oskadon,bintangToedjoe,antalgin,
            aspilets,biogesic,LbErlamycetin,LbInstoRegularEyeDrops,LbInstoDryEyes,LbOhtoCoolEye,LbCTobroson,LbAlconTears,
            LbCFloxa,LbCCenfresh,LbVisineExtraEye,LbAlletrolCompositum,LbCHyalub,LbCMoncort,aleva,ibuProfen,Diclofenac,recofar,
            mp,al,ac,ce,as,celeco,cc,hi,ademSari,betadine,degirol,larutan,
            spTroches,strepsilCool,aloclair,tantumLozenges,jesscool,listerine,cooling,tantum
        };
        
        btP = new JButton[]{
            p37,p38,p39,p40,p41,p42,p43,p44,p45,p46,p47,p48,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p26,p27,p28,
            p29,p33,p32,p31,p30,p34,p35,p36,p13,p14,p15,p16,p17,p18,p19,
            p20,p21,p22,p23,p24,p25
        };
        
        btM = new JButton[]{
            m37,m38,m39,m40,m41,m42,m43,m44,m45,m46,m47,m48,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m26,m27,m28,
            m29,m33,m32,m31,m30,m34,m35,m36,m13,m14,m15,m16,m17,m18,m19,
            m20,m21,m22,m23,m24,m25
        };
        
        tx = new JTextField[]{
            txPanadolHijau,txPanadolBiru,txPanadolMerah,txBodrexExtra,txParamex,txPanadolAnak, txSaridon,txOskadon,
            txBintang7,txAntalgin,txAspilet,txBiogesic,erlamycetin,instoDropEye,instoDryEye,ohtoCoolEye,cTobroson,alconTears,
            cFloxa,cCenfresh,visine,alletrol,cHyalub,cMoncort,aleveNaproxen,ibuprofen,diclofenac,recolfar,methylprednisolone,
            allopurinol,aclonac,celebrex,aspirin,celecoxib,counterpain,hiD,count14,count15,count16,count17,count18,count19,count20,count21,
            count22,count23,count24,count25
        };
        for(int i = 0; i < lbl.length; i++){
            String sqlGetStok = "SELECT * from OBAT WHERE NAMAOBAT=?";
            connect.con = getKoneksi();
               
            try{
                connect.pst = connect.con.prepareStatement(sqlGetStok);
                connect.pst.setString(1, lbl[i].getText());
                connect.rs = connect.pst.executeQuery();

                if(connect.rs.next()){
                    int stok = connect.rs.getInt("STOK");
                    if(Integer.parseInt(tx[i].getText()) <= stok){
                        setBanyakPembelian(btP[i],tx[i],btM[i],lbl[i]); // Implementasi dari interface
                        
                    }else{
                        // Kondisi jika user memesan obat melebihi stok
                        JOptionPane.showMessageDialog(null, "Obat " + lbl[i].getText() + " yang Anda pesan melebihi stok kami");
                    }
                }
            }catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tempU = new javax.swing.JLabel();
        tempPass = new javax.swing.JLabel();
        menuPanel = new javax.swing.JPanel();
        pembelianObat = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        btMata = new javax.swing.JButton();
        btKepala = new javax.swing.JButton();
        btKaki = new javax.swing.JButton();
        btMulut = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        mataPanel = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        LbErlamycetin = new javax.swing.JLabel();
        LbInstoRegularEyeDrops = new javax.swing.JLabel();
        LbInstoDryEyes = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        LbOhtoCoolEye = new javax.swing.JLabel();
        LbCTobroson = new javax.swing.JLabel();
        LbAlconTears = new javax.swing.JLabel();
        LbCFloxa = new javax.swing.JLabel();
        LbCCenfresh = new javax.swing.JLabel();
        LbVisineExtraEye = new javax.swing.JLabel();
        LbAlletrolCompositum = new javax.swing.JLabel();
        LbCHyalub = new javax.swing.JLabel();
        LbCMoncort = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        instoDropEye = new javax.swing.JTextField();
        p12 = new javax.swing.JButton();
        m12 = new javax.swing.JButton();
        cMoncort = new javax.swing.JTextField();
        p1 = new javax.swing.JButton();
        erlamycetin = new javax.swing.JTextField();
        instoDryEye = new javax.swing.JTextField();
        ohtoCoolEye = new javax.swing.JTextField();
        cCenfresh = new javax.swing.JTextField();
        cFloxa = new javax.swing.JTextField();
        alconTears = new javax.swing.JTextField();
        cTobroson = new javax.swing.JTextField();
        visine = new javax.swing.JTextField();
        alletrol = new javax.swing.JTextField();
        cHyalub = new javax.swing.JTextField();
        p2 = new javax.swing.JButton();
        p3 = new javax.swing.JButton();
        p4 = new javax.swing.JButton();
        p8 = new javax.swing.JButton();
        p7 = new javax.swing.JButton();
        p6 = new javax.swing.JButton();
        p5 = new javax.swing.JButton();
        p9 = new javax.swing.JButton();
        p10 = new javax.swing.JButton();
        p11 = new javax.swing.JButton();
        m1 = new javax.swing.JButton();
        m2 = new javax.swing.JButton();
        m3 = new javax.swing.JButton();
        m4 = new javax.swing.JButton();
        m8 = new javax.swing.JButton();
        m7 = new javax.swing.JButton();
        m6 = new javax.swing.JButton();
        m5 = new javax.swing.JButton();
        m9 = new javax.swing.JButton();
        m10 = new javax.swing.JButton();
        m11 = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        btPembayaran3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        mulutPanel = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        ademSari = new javax.swing.JLabel();
        betadine = new javax.swing.JLabel();
        degirol = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        larutan = new javax.swing.JLabel();
        spTroches = new javax.swing.JLabel();
        strepsilCool = new javax.swing.JLabel();
        aloclair = new javax.swing.JLabel();
        tantumLozenges = new javax.swing.JLabel();
        jesscool = new javax.swing.JLabel();
        listerine = new javax.swing.JLabel();
        cooling = new javax.swing.JLabel();
        tantum = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        count15 = new javax.swing.JTextField();
        p25 = new javax.swing.JButton();
        m25 = new javax.swing.JButton();
        count25 = new javax.swing.JTextField();
        p14 = new javax.swing.JButton();
        count14 = new javax.swing.JTextField();
        count16 = new javax.swing.JTextField();
        count17 = new javax.swing.JTextField();
        count18 = new javax.swing.JTextField();
        count19 = new javax.swing.JTextField();
        count20 = new javax.swing.JTextField();
        count21 = new javax.swing.JTextField();
        count22 = new javax.swing.JTextField();
        count23 = new javax.swing.JTextField();
        count24 = new javax.swing.JTextField();
        p15 = new javax.swing.JButton();
        p16 = new javax.swing.JButton();
        p17 = new javax.swing.JButton();
        p18 = new javax.swing.JButton();
        p19 = new javax.swing.JButton();
        p20 = new javax.swing.JButton();
        p21 = new javax.swing.JButton();
        p22 = new javax.swing.JButton();
        p23 = new javax.swing.JButton();
        p24 = new javax.swing.JButton();
        m14 = new javax.swing.JButton();
        m15 = new javax.swing.JButton();
        m16 = new javax.swing.JButton();
        m17 = new javax.swing.JButton();
        m18 = new javax.swing.JButton();
        m19 = new javax.swing.JButton();
        m20 = new javax.swing.JButton();
        m21 = new javax.swing.JButton();
        m22 = new javax.swing.JButton();
        m23 = new javax.swing.JButton();
        m24 = new javax.swing.JButton();
        jLabel87 = new javax.swing.JLabel();
        btPembayaran2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel43 = new javax.swing.JLabel();
        kepalaPanel = new javax.swing.JPanel();
        jLabel126 = new javax.swing.JLabel();
        panadolHijau = new javax.swing.JLabel();
        panadolBiru = new javax.swing.JLabel();
        panadolMerah = new javax.swing.JLabel();
        jLabel130 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        bodrexExtra = new javax.swing.JLabel();
        paramex = new javax.swing.JLabel();
        panadolAnak = new javax.swing.JLabel();
        saridon = new javax.swing.JLabel();
        oskadon = new javax.swing.JLabel();
        bintangToedjoe = new javax.swing.JLabel();
        antalgin = new javax.swing.JLabel();
        aspilets = new javax.swing.JLabel();
        biogesic = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        jLabel143 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        jLabel148 = new javax.swing.JLabel();
        jLabel149 = new javax.swing.JLabel();
        jLabel150 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        jLabel154 = new javax.swing.JLabel();
        jLabel155 = new javax.swing.JLabel();
        jLabel156 = new javax.swing.JLabel();
        jLabel157 = new javax.swing.JLabel();
        jLabel158 = new javax.swing.JLabel();
        jLabel159 = new javax.swing.JLabel();
        jLabel160 = new javax.swing.JLabel();
        txPanadolBiru = new javax.swing.JTextField();
        p48 = new javax.swing.JButton();
        m48 = new javax.swing.JButton();
        txBiogesic = new javax.swing.JTextField();
        p37 = new javax.swing.JButton();
        txPanadolHijau = new javax.swing.JTextField();
        txPanadolMerah = new javax.swing.JTextField();
        txBodrexExtra = new javax.swing.JTextField();
        txOskadon = new javax.swing.JTextField();
        txSaridon = new javax.swing.JTextField();
        txPanadolAnak = new javax.swing.JTextField();
        txParamex = new javax.swing.JTextField();
        txBintang7 = new javax.swing.JTextField();
        txAntalgin = new javax.swing.JTextField();
        txAspilet = new javax.swing.JTextField();
        p38 = new javax.swing.JButton();
        p39 = new javax.swing.JButton();
        p40 = new javax.swing.JButton();
        p44 = new javax.swing.JButton();
        p43 = new javax.swing.JButton();
        p42 = new javax.swing.JButton();
        p41 = new javax.swing.JButton();
        p45 = new javax.swing.JButton();
        p46 = new javax.swing.JButton();
        p47 = new javax.swing.JButton();
        m37 = new javax.swing.JButton();
        m38 = new javax.swing.JButton();
        m39 = new javax.swing.JButton();
        m40 = new javax.swing.JButton();
        m44 = new javax.swing.JButton();
        m43 = new javax.swing.JButton();
        m42 = new javax.swing.JButton();
        m41 = new javax.swing.JButton();
        m45 = new javax.swing.JButton();
        m46 = new javax.swing.JButton();
        m47 = new javax.swing.JButton();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        btPembayaran = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        design = new javax.swing.JLabel();
        pembayaranPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBelanjaan = new javax.swing.JTable();
        jLabel89 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        hargaTotal = new javax.swing.JLabel();
        uang = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        kakiPanel = new javax.swing.JPanel();
        jLabel88 = new javax.swing.JLabel();
        aleva = new javax.swing.JLabel();
        ibuProfen = new javax.swing.JLabel();
        Diclofenac = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        recofar = new javax.swing.JLabel();
        mp = new javax.swing.JLabel();
        al = new javax.swing.JLabel();
        ac = new javax.swing.JLabel();
        ce = new javax.swing.JLabel();
        as = new javax.swing.JLabel();
        celeco = new javax.swing.JLabel();
        cc = new javax.swing.JLabel();
        hi = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        hiD = new javax.swing.JTextField();
        p13 = new javax.swing.JButton();
        m13 = new javax.swing.JButton();
        aleveNaproxen = new javax.swing.JTextField();
        p26 = new javax.swing.JButton();
        ibuprofen = new javax.swing.JTextField();
        diclofenac = new javax.swing.JTextField();
        recolfar = new javax.swing.JTextField();
        celebrex = new javax.swing.JTextField();
        aclonac = new javax.swing.JTextField();
        allopurinol = new javax.swing.JTextField();
        methylprednisolone = new javax.swing.JTextField();
        aspirin = new javax.swing.JTextField();
        celecoxib = new javax.swing.JTextField();
        counterpain = new javax.swing.JTextField();
        p27 = new javax.swing.JButton();
        p28 = new javax.swing.JButton();
        p29 = new javax.swing.JButton();
        p30 = new javax.swing.JButton();
        p31 = new javax.swing.JButton();
        p32 = new javax.swing.JButton();
        p33 = new javax.swing.JButton();
        p34 = new javax.swing.JButton();
        p35 = new javax.swing.JButton();
        p36 = new javax.swing.JButton();
        m26 = new javax.swing.JButton();
        m27 = new javax.swing.JButton();
        m28 = new javax.swing.JButton();
        m29 = new javax.swing.JButton();
        m30 = new javax.swing.JButton();
        m31 = new javax.swing.JButton();
        m32 = new javax.swing.JButton();
        m33 = new javax.swing.JButton();
        m34 = new javax.swing.JButton();
        m35 = new javax.swing.JButton();
        m36 = new javax.swing.JButton();
        jLabel124 = new javax.swing.JLabel();
        jLabel125 = new javax.swing.JLabel();
        btPembayaran1 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel163 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btCekKesehatan = new javax.swing.JButton();
        btBeliObat = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        namaAcc = new javax.swing.JLabel();
        btKeluar = new javax.swing.JButton();
        btCredit = new javax.swing.JButton();
        btHome = new javax.swing.JButton();
        btBiodata = new javax.swing.JButton();

        tempU.setText("jLabel7");

        tempPass.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuPanel.setBackground(new java.awt.Color(255, 255, 255));
        menuPanel.setLayout(new java.awt.CardLayout());

        pembelianObat.setBackground(new java.awt.Color(255, 255, 255));
        pembelianObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel5.setText("Obat & Vitamin");
        pembelianObat.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, -1, 80));

        btMata.setBackground(new java.awt.Color(210, 180, 140));
        btMata.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        btMata.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/mataa.png"))); // NOI18N
        btMata.setText("Mata");
        btMata.setAlignmentY(0.0F);
        btMata.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btMata.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btMata.setIconTextGap(20);
        btMata.setMargin(new java.awt.Insets(1, 14, 1, 14));
        btMata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMataActionPerformed(evt);
            }
        });
        pembelianObat.add(btMata, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 190, 60));

        btKepala.setBackground(new java.awt.Color(210, 180, 140));
        btKepala.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        btKepala.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/kepalaa.png"))); // NOI18N
        btKepala.setText("kepala");
        btKepala.setAlignmentY(0.0F);
        btKepala.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btKepala.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btKepala.setIconTextGap(20);
        btKepala.setMargin(new java.awt.Insets(1, 14, 1, 14));
        btKepala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btKepalaActionPerformed(evt);
            }
        });
        pembelianObat.add(btKepala, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 190, 60));

        btKaki.setBackground(new java.awt.Color(210, 180, 140));
        btKaki.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        btKaki.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/kakii.png"))); // NOI18N
        btKaki.setText("kaki");
        btKaki.setAlignmentY(0.0F);
        btKaki.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btKaki.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btKaki.setIconTextGap(20);
        btKaki.setMargin(new java.awt.Insets(1, 14, 1, 14));
        btKaki.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btKakiActionPerformed(evt);
            }
        });
        pembelianObat.add(btKaki, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 470, 190, -1));

        btMulut.setBackground(new java.awt.Color(210, 180, 140));
        btMulut.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        btMulut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/mulut.png"))); // NOI18N
        btMulut.setText("Mulut");
        btMulut.setAlignmentY(0.0F);
        btMulut.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btMulut.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btMulut.setIconTextGap(20);
        btMulut.setMargin(new java.awt.Insets(1, 14, 1, 14));
        btMulut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMulutActionPerformed(evt);
            }
        });
        pembelianObat.add(btMulut, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 380, 190, 60));

        jLabel6.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        jLabel6.setText("Pilih bagian Keluhan Anda");
        pembelianObat.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 560, 90));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Segoe Print", 2, 36)); // NOI18N
        jLabel4.setText("Obat & Vitamin");
        pembelianObat.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 280, -1, 60));

        jLabel8.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel8.setText("vitamin sesuai keluhan anda");
        pembelianObat.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 440, 320, 50));

        jLabel9.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel9.setText("Apibila anda mempunyai keluhan");
        pembelianObat.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 340, 270, 50));

        jLabel10.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel10.setText("pilihan lah sesuai bagian keluhan anda");
        pembelianObat.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 370, 320, 50));

        jLabel11.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel11.setText("insyaallah tersedia berbagai obat dan");
        pembelianObat.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 400, 320, 50));

        jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        jLabel12.setFont(new java.awt.Font("Segoe Print", 2, 36)); // NOI18N
        jLabel12.setText("Tersedia Berbagai Jenis ");
        pembelianObat.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, -1, 60));
        pembelianObat.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 450, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/obat.jpg"))); // NOI18N
        pembelianObat.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 340, 280, 260));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/sakit.jpg"))); // NOI18N
        pembelianObat.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 480, -1, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Free UI Design v.1.10.png"))); // NOI18N
        pembelianObat.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 0, -1, -1));

        menuPanel.add(pembelianObat, "card2");

        mataPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("15 ML");
        mataPanel.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 130, 20));

        LbErlamycetin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbErlamycetin.setText("ERLAMYCETIN SALEP ");
        mataPanel.add(LbErlamycetin, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 130, 20));

        LbInstoRegularEyeDrops.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbInstoRegularEyeDrops.setText("Insto Regular Eye Drops");
        mataPanel.add(LbInstoRegularEyeDrops, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 130, 20));

        LbInstoDryEyes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbInstoDryEyes.setText("INSTO DRY EYES");
        mataPanel.add(LbInstoDryEyes, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, 130, 20));

        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setText("7.5 ML");
        mataPanel.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 140, 140, -1));

        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setText("MATA 3.5 G");
        mataPanel.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 130, -1));

        LbOhtoCoolEye.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbOhtoCoolEye.setText("OHTO COOL EYE  ");
        mataPanel.add(LbOhtoCoolEye, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 120, 140, 20));

        LbCTobroson.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        LbCTobroson.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbCTobroson.setText("C TOBROSON MINIDOSE ");
        mataPanel.add(LbCTobroson, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, 130, 30));

        LbAlconTears.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        LbAlconTears.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbAlconTears.setText("ALCON TEARS NATURALE");
        mataPanel.add(LbAlconTears, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 140, 20));

        LbCFloxa.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        LbCFloxa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbCFloxa.setText("CENDO FLOXA MINIDOSE");
        mataPanel.add(LbCFloxa, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 310, 140, 30));

        LbCCenfresh.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        LbCCenfresh.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbCCenfresh.setText("C CENFRESH MINIDOSE");
        mataPanel.add(LbCCenfresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 310, 150, 30));

        LbVisineExtraEye.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbVisineExtraEye.setText("VISINE EXTRA EYE");
        mataPanel.add(LbVisineExtraEye, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 130, 30));

        LbAlletrolCompositum.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbAlletrolCompositum.setText("ALLETROL COMPOSITUM ");
        mataPanel.add(LbAlletrolCompositum, new org.netbeans.lib.awtextra.AbsoluteConstraints(211, 550, 140, 30));

        LbCHyalub.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        LbCHyalub.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbCHyalub.setText("C HYALUB MINIDOSE ");
        mataPanel.add(LbCHyalub, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 540, 140, 30));

        LbCMoncort.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        LbCMoncort.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LbCMoncort.setText("C NONCORT MINIDOSE ");
        mataPanel.add(LbCMoncort, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 530, 150, 30));

        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setText("0.6 ML");
        mataPanel.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 130, -1));

        jLabel55.setText("15 ML");
        mataPanel.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 350, -1, -1));

        jLabel56.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel56.setText(" 0.6 ML");
        mataPanel.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 330, 140, 30));

        jLabel57.setText("0.6 ML");
        mataPanel.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 340, -1, -1));

        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel58.setText("  6 ML");
        mataPanel.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 580, 130, 30));

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("5 ML");
        mataPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 580, 140, -1));

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("0.6 ML");
        mataPanel.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 560, 130, 20));

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("0.6 ML");
        mataPanel.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 560, 130, -1));

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Rp. 61000");
        mataPanel.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 160, 130, -1));

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("Rp. 27000");
        mataPanel.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 160, 130, -1));

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("Rp. 22000");
        mataPanel.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 130, -1));

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("Rp. 17000");
        mataPanel.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 130, -1));

        jLabel25.setText("Rp. 78500");
        mataPanel.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 360, -1, -1));

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("Rp. 55000");
        mataPanel.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 360, 130, 20));

        jLabel28.setText("Rp. 22800");
        mataPanel.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 370, -1, -1));

        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("Rp. 72400");
        mataPanel.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 130, -1));

        jLabel30.setText("Rp. 11000");
        mataPanel.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 580, -1, -1));

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Rp. 21000");
        mataPanel.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 580, 150, 20));

        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setText("Rp. 15700");
        mataPanel.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 600, 150, -1));

        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Rp. 80000");
        mataPanel.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 610, 150, -1));

        instoDropEye.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        instoDropEye.setText("0");
        mataPanel.add(instoDropEye, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 200, 30, 30));

        p12.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p12.setText("+");
        mataPanel.add(p12, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 630, 40, 30));

        m12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m12.setText("-");
        mataPanel.add(m12, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 630, 40, 30));

        cMoncort.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cMoncort.setText("0");
        mataPanel.add(cMoncort, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 630, 30, 30));

        p1.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p1.setText("+");
        mataPanel.add(p1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 40, 30));

        erlamycetin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        erlamycetin.setText("0");
        mataPanel.add(erlamycetin, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 30, 30));

        instoDryEye.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        instoDryEye.setText("0");
        mataPanel.add(instoDryEye, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 30, 30));

        ohtoCoolEye.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ohtoCoolEye.setText("0");
        mataPanel.add(ohtoCoolEye, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 30, 30));

        cCenfresh.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cCenfresh.setText("0");
        mataPanel.add(cCenfresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 420, 30, 30));

        cFloxa.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cFloxa.setText("0");
        mataPanel.add(cFloxa, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 30, 30));

        alconTears.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        alconTears.setText("0");
        mataPanel.add(alconTears, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 420, 30, 30));

        cTobroson.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cTobroson.setText("0");
        mataPanel.add(cTobroson, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 30, 30));

        visine.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        visine.setText("0");
        mataPanel.add(visine, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 30, 30));

        alletrol.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        alletrol.setText("0");
        mataPanel.add(alletrol, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 630, 30, 30));

        cHyalub.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cHyalub.setText("0");
        mataPanel.add(cHyalub, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 630, 30, 30));

        p2.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p2.setText("+");
        mataPanel.add(p2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 40, 30));

        p3.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p3.setText("+");
        mataPanel.add(p3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 200, 40, 30));

        p4.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p4.setText("+");
        mataPanel.add(p4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 200, 40, 30));

        p8.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p8.setText("+");
        mataPanel.add(p8, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, 40, 30));

        p7.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p7.setText("+");
        mataPanel.add(p7, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 420, 40, 30));

        p6.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p6.setText("+");
        mataPanel.add(p6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 420, 40, 30));

        p5.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p5.setText("+");
        mataPanel.add(p5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, 40, 30));

        p9.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p9.setText("+");
        mataPanel.add(p9, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 630, 40, 30));

        p10.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p10.setText("+");
        mataPanel.add(p10, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 630, 40, 30));

        p11.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p11.setText("+");
        mataPanel.add(p11, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 630, 40, 30));

        m1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m1.setText("-");
        mataPanel.add(m1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 40, 30));

        m2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m2.setText("-");
        mataPanel.add(m2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 40, 30));

        m3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m3.setText("-");
        mataPanel.add(m3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, 40, 30));

        m4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m4.setText("-");
        mataPanel.add(m4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 200, 40, 30));

        m8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m8.setText("-");
        mataPanel.add(m8, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 40, 30));

        m7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m7.setText("-");
        mataPanel.add(m7, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 420, 40, 30));

        m6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m6.setText("-");
        mataPanel.add(m6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 40, 30));

        m5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m5.setText("-");
        mataPanel.add(m5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 40, 30));

        m9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m9.setText("-");
        mataPanel.add(m9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 630, 40, 30));

        m10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m10.setText("-");
        mataPanel.add(m10, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 630, 40, 30));

        m11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m11.setText("-");
        mataPanel.add(m11, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 630, 40, 30));

        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("7.5 ML ");
        mataPanel.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 140, 130, 20));

        btPembayaran3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/keranjang.png"))); // NOI18N
        btPembayaran3.setText("Masukkan Keranjang");
        btPembayaran3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPembayaran3ActionPerformed(evt);
            }
        });
        mataPanel.add(btPembayaran3, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, 220, 40));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back_12955.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        mataPanel.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(995, 10, 60, 40));

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Obat Mata UI v.2.0.png"))); // NOI18N
        mataPanel.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        menuPanel.add(mataPanel, "card5");

        mulutPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("190 ML");
        mulutPanel.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 130, 20));

        ademSari.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ademSari.setText("ADEM SARI JUMBO");
        mulutPanel.add(ademSari, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 140, 30));

        betadine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        betadine.setText("BETADINE OBAT KUMUR");
        mulutPanel.add(betadine, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 140, 20));

        degirol.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        degirol.setText("DEGIROL HISAP ");
        mulutPanel.add(degirol, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, 130, 20));

        jLabel59.setText("BOTOL 200 ML");
        mulutPanel.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 150, 90, -1));

        jLabel60.setText("5 SACHET");
        mulutPanel.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 80, -1));

        larutan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        larutan.setText("LARUTAN KAKI TIGA ");
        mulutPanel.add(larutan, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 140, 20));

        spTroches.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        spTroches.setText("SP TROCHES MEIJI ");
        mulutPanel.add(spTroches, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, 130, 30));

        strepsilCool.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        strepsilCool.setText("STREPSIL COOL MENTHOL");
        mulutPanel.add(strepsilCool, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 140, 20));

        aloclair.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        aloclair.setText("ALOCLAIR PLUS GEL");
        mulutPanel.add(aloclair, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 330, 140, 30));

        tantumLozenges.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tantumLozenges.setText("TANTUM LOZENGES ");
        mulutPanel.add(tantumLozenges, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 320, 150, 30));

        jesscool.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jesscool.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jesscool.setText("JESSCOOL EFFERVESCENT");
        mulutPanel.add(jesscool, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 530, 140, 30));

        listerine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        listerine.setText("LISTERINE COOL MINT ");
        mulutPanel.add(listerine, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 550, 160, 30));

        cooling.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        cooling.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cooling.setText("COOLING 5 PLUS ORANGE ");
        mulutPanel.add(cooling, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 560, 130, 30));

        tantum.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        tantum.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tantum.setText("TANTUM VERDE SOLUTION ");
        mulutPanel.add(tantum, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 560, 150, 30));

        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel68.setText(" 12 TABLET");
        mulutPanel.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 340, 90, -1));

        jLabel69.setText(" 12 TABLET");
        mulutPanel.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 350, -1, -1));

        jLabel70.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel70.setText(" 8 ML");
        mulutPanel.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 350, 140, 30));

        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setText("12 TABLET");
        mulutPanel.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 340, 70, 20));

        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel72.setText(" 1 TABLET");
        mulutPanel.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 550, 130, 30));

        jLabel38.setText(" 250 ML");
        mulutPanel.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 570, 50, -1));

        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel73.setText("15 ML");
        mulutPanel.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 580, 130, 20));

        jLabel74.setText("60 ML");
        mulutPanel.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 580, 50, 20));

        jLabel75.setText("Rp. 4000");
        mulutPanel.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 170, 70, -1));

        jLabel76.setText("Rp. 6500");
        mulutPanel.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 160, -1, -1));

        jLabel77.setText("Rp. 23000");
        mulutPanel.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, -1, -1));

        jLabel78.setText("Rp. 25000");
        mulutPanel.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 70, -1));

        jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel79.setText("Rp. 48500");
        mulutPanel.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 360, 140, -1));

        jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel80.setText("Rp. 85000");
        mulutPanel.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 370, 130, 20));

        jLabel81.setText("Rp. 12800");
        mulutPanel.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 370, 60, -1));

        jLabel82.setText("Rp. 15000");
        mulutPanel.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 360, 70, -1));

        jLabel83.setText("Rp. 25000");
        mulutPanel.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 600, -1, -1));

        jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel84.setText("Rp. 34000");
        mulutPanel.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 600, 130, 20));

        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel85.setText("Rp. 18000");
        mulutPanel.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 590, 80, -1));

        jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel86.setText("Rp. 5000");
        mulutPanel.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 580, 130, -1));

        count15.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count15.setText("0");
        mulutPanel.add(count15, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 200, 30, 30));

        p25.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p25.setText("+");
        mulutPanel.add(p25, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 630, 40, 30));

        m25.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m25.setText("-");
        mulutPanel.add(m25, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 630, 40, 30));

        count25.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count25.setText("0");
        mulutPanel.add(count25, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 630, 30, 30));

        p14.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p14.setText("+");
        mulutPanel.add(p14, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 40, 30));

        count14.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count14.setText("0");
        count14.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                count14KeyReleased(evt);
            }
        });
        mulutPanel.add(count14, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 30, 30));

        count16.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count16.setText("0");
        mulutPanel.add(count16, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 30, 30));

        count17.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count17.setText("0");
        mulutPanel.add(count17, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 30, 30));

        count18.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count18.setText("0");
        mulutPanel.add(count18, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 420, 30, 30));

        count19.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count19.setText("0");
        mulutPanel.add(count19, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 30, 30));

        count20.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count20.setText("0");
        mulutPanel.add(count20, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 420, 30, 30));

        count21.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count21.setText("0");
        mulutPanel.add(count21, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 30, 30));

        count22.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count22.setText("0");
        mulutPanel.add(count22, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 30, 30));

        count23.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count23.setText("0");
        mulutPanel.add(count23, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 630, 30, 30));

        count24.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        count24.setText("0");
        mulutPanel.add(count24, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 630, 30, 30));

        p15.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p15.setText("+");
        mulutPanel.add(p15, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 40, 30));

        p16.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p16.setText("+");
        mulutPanel.add(p16, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 200, 40, 30));

        p17.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p17.setText("+");
        mulutPanel.add(p17, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 200, 40, 30));

        p18.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p18.setText("+");
        mulutPanel.add(p18, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, 40, 30));

        p19.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p19.setText("+");
        mulutPanel.add(p19, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 420, 40, 30));

        p20.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p20.setText("+");
        mulutPanel.add(p20, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 420, 40, 30));

        p21.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p21.setText("+");
        mulutPanel.add(p21, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, 40, 30));

        p22.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p22.setText("+");
        mulutPanel.add(p22, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 630, 40, 30));

        p23.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p23.setText("+");
        mulutPanel.add(p23, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 630, 40, 30));

        p24.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p24.setText("+");
        mulutPanel.add(p24, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 630, 40, 30));

        m14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m14.setText("-");
        mulutPanel.add(m14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 40, 30));

        m15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m15.setText("-");
        mulutPanel.add(m15, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 40, 30));

        m16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m16.setText("-");
        mulutPanel.add(m16, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, 40, 30));

        m17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m17.setText("-");
        mulutPanel.add(m17, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 200, 40, 30));

        m18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m18.setText("-");
        mulutPanel.add(m18, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 40, 30));

        m19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m19.setText("-");
        mulutPanel.add(m19, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 420, 40, 30));

        m20.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m20.setText("-");
        mulutPanel.add(m20, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 40, 30));

        m21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m21.setText("-");
        mulutPanel.add(m21, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 40, 30));

        m22.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m22.setText("-");
        mulutPanel.add(m22, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 630, 40, 30));

        m23.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m23.setText("-");
        mulutPanel.add(m23, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 630, 40, 30));

        m24.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m24.setText("-");
        mulutPanel.add(m24, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 630, 40, 30));

        jLabel87.setText("0.25 MG");
        mulutPanel.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 140, -1, -1));

        btPembayaran2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/keranjang.png"))); // NOI18N
        btPembayaran2.setText("Masukkan Keranjang");
        btPembayaran2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPembayaran2ActionPerformed(evt);
            }
        });
        mulutPanel.add(btPembayaran2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, 220, 40));

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back_12955.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        mulutPanel.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(995, 10, 60, 40));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/UI Mulut v.1.00.png"))); // NOI18N
        mulutPanel.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        menuPanel.add(mulutPanel, "card4");

        kepalaPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel126.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel126.setText("500 MG");
        kepalaPanel.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 140, 20));

        panadolHijau.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panadolHijau.setText("PANADOL COLD-FLU");
        kepalaPanel.add(panadolHijau, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 130, 20));

        panadolBiru.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panadolBiru.setText("PANADOL PARACETAMOL");
        kepalaPanel.add(panadolBiru, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 140, 20));

        panadolMerah.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panadolMerah.setText("PANADOL EXTRA");
        kepalaPanel.add(panadolMerah, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, 130, 20));

        jLabel130.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel130.setText("300 MG");
        kepalaPanel.add(jLabel130, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 134, 130, 30));

        jLabel131.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel131.setText("500 MG");
        kepalaPanel.add(jLabel131, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 130, 20));

        bodrexExtra.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bodrexExtra.setText("BODREX EXTRA");
        kepalaPanel.add(bodrexExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 120, 140, 20));

        paramex.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        paramex.setText("PARAMEX");
        kepalaPanel.add(paramex, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 130, 30));

        panadolAnak.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panadolAnak.setText("PANADOL ANAK");
        kepalaPanel.add(panadolAnak, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 140, 30));

        saridon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        saridon.setText("SARIDON");
        kepalaPanel.add(saridon, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 330, 140, 30));

        oskadon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        oskadon.setText("OSKADON");
        kepalaPanel.add(oskadon, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, 130, 30));

        bintangToedjoe.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bintangToedjoe.setText("BINTANG TOEDJOE");
        kepalaPanel.add(bintangToedjoe, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 540, 130, 30));

        antalgin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        antalgin.setText("ANTALGIN");
        kepalaPanel.add(antalgin, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 540, 130, 30));

        aspilets.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        aspilets.setText("ASPILETS");
        kepalaPanel.add(aspilets, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 540, 140, 30));

        biogesic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        biogesic.setText("BIOGESIC");
        kepalaPanel.add(biogesic, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 540, 130, 30));

        jLabel141.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel141.setText("250 MG");
        kepalaPanel.add(jLabel141, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 130, 30));

        jLabel142.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel142.setText("120 MG");
        kepalaPanel.add(jLabel142, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 354, 140, 20));

        jLabel143.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel143.setText("250  MG");
        kepalaPanel.add(jLabel143, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 350, 140, 30));

        jLabel144.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel144.setText("500 MG");
        kepalaPanel.add(jLabel144, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 350, 130, 30));

        jLabel145.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel145.setText("275 MG");
        kepalaPanel.add(jLabel145, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 130, 30));

        jLabel146.setText("500 MG");
        kepalaPanel.add(jLabel146, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 560, -1, 30));

        jLabel147.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel147.setText("80 MG");
        kepalaPanel.add(jLabel147, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 560, 140, 30));

        jLabel148.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel148.setText("500 GRAM");
        kepalaPanel.add(jLabel148, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 560, -1, 30));

        jLabel149.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel149.setText("Rp. 6.500");
        kepalaPanel.add(jLabel149, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 160, 130, 20));

        jLabel150.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel150.setText("Rp. 19.000");
        kepalaPanel.add(jLabel150, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 154, 150, 30));

        jLabel151.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel151.setText("Rp. 20.000");
        kepalaPanel.add(jLabel151, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 140, 40));

        jLabel152.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel152.setText("Rp. 20.000");
        kepalaPanel.add(jLabel152, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 154, 130, 30));

        jLabel153.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel153.setText("Rp.5.200");
        kepalaPanel.add(jLabel153, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 364, 130, 40));

        jLabel154.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel154.setText("Rp. 7.000");
        kepalaPanel.add(jLabel154, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 370, 140, 30));

        jLabel155.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel155.setText("Rp. 25.000");
        kepalaPanel.add(jLabel155, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 370, 140, 30));

        jLabel156.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel156.setText("Rp. 6.500");
        kepalaPanel.add(jLabel156, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 374, 130, 30));

        jLabel157.setText("Rp. 5.200");
        kepalaPanel.add(jLabel157, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 584, -1, 20));

        jLabel158.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel158.setText("Rp. 15.000");
        kepalaPanel.add(jLabel158, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 580, 140, 30));

        jLabel159.setText("Rp. 15.700");
        kepalaPanel.add(jLabel159, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 590, -1, -1));

        jLabel160.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel160.setText("Rp. 17.000");
        kepalaPanel.add(jLabel160, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 590, 130, -1));

        txPanadolBiru.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txPanadolBiru.setText("0");
        kepalaPanel.add(txPanadolBiru, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 180, 30, 30));

        p48.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p48.setText("+");
        kepalaPanel.add(p48, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 610, 40, 30));

        m48.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m48.setText("-");
        kepalaPanel.add(m48, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 610, 40, 30));

        txBiogesic.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txBiogesic.setText("0");
        kepalaPanel.add(txBiogesic, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 610, 30, 30));

        p37.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p37.setText("+");
        kepalaPanel.add(p37, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 40, 30));

        txPanadolHijau.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txPanadolHijau.setText("0");
        kepalaPanel.add(txPanadolHijau, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 30, 30));

        txPanadolMerah.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txPanadolMerah.setText("0");
        kepalaPanel.add(txPanadolMerah, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 180, 30, 30));

        txBodrexExtra.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txBodrexExtra.setText("0");
        kepalaPanel.add(txBodrexExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 180, 30, 30));

        txOskadon.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txOskadon.setText("0");
        kepalaPanel.add(txOskadon, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, 30, 30));

        txSaridon.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txSaridon.setText("0");
        kepalaPanel.add(txSaridon, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 400, 30, 30));

        txPanadolAnak.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txPanadolAnak.setText("0");
        kepalaPanel.add(txPanadolAnak, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 400, 30, 30));

        txParamex.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txParamex.setText("0");
        kepalaPanel.add(txParamex, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, 30, 30));

        txBintang7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txBintang7.setText("0");
        kepalaPanel.add(txBintang7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 610, 30, 30));

        txAntalgin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txAntalgin.setText("0");
        kepalaPanel.add(txAntalgin, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 610, 30, 30));

        txAspilet.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txAspilet.setText("0");
        kepalaPanel.add(txAspilet, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 610, 30, 30));

        p38.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p38.setText("+");
        kepalaPanel.add(p38, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, 40, 30));

        p39.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p39.setText("+");
        kepalaPanel.add(p39, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 180, 40, 30));

        p40.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p40.setText("+");
        kepalaPanel.add(p40, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 180, 40, 30));

        p44.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p44.setText("+");
        kepalaPanel.add(p44, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 400, 40, 30));

        p43.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p43.setText("+");
        kepalaPanel.add(p43, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 400, 40, 30));

        p42.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p42.setText("+");
        kepalaPanel.add(p42, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, 40, 30));

        p41.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p41.setText("+");
        kepalaPanel.add(p41, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 400, 40, 30));

        p45.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p45.setText("+");
        kepalaPanel.add(p45, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 610, 40, 30));

        p46.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p46.setText("+");
        kepalaPanel.add(p46, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 610, 40, 30));

        p47.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p47.setText("+");
        kepalaPanel.add(p47, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 610, 40, 30));

        m37.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m37.setText("-");
        kepalaPanel.add(m37, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 40, 30));

        m38.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m38.setText("-");
        kepalaPanel.add(m38, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, 40, 30));

        m39.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m39.setText("-");
        kepalaPanel.add(m39, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, 40, 30));

        m40.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m40.setText("-");
        kepalaPanel.add(m40, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, 40, 30));

        m44.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m44.setText("-");
        kepalaPanel.add(m44, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 400, 40, 30));

        m43.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m43.setText("-");
        kepalaPanel.add(m43, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 400, 40, 30));

        m42.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m42.setText("-");
        kepalaPanel.add(m42, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, 40, 30));

        m41.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m41.setText("-");
        kepalaPanel.add(m41, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, 40, 30));

        m45.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m45.setText("-");
        kepalaPanel.add(m45, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, 40, 30));

        m46.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m46.setText("-");
        kepalaPanel.add(m46, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 610, 40, 30));

        m47.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m47.setText("-");
        kepalaPanel.add(m47, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 610, 40, 30));

        jLabel161.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel161.setText("500 MG");
        kepalaPanel.add(jLabel161, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 140, 150, 20));
        kepalaPanel.add(jLabel162, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        btPembayaran.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/keranjang.png"))); // NOI18N
        btPembayaran.setText("Masukkan Keranjang");
        btPembayaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPembayaranActionPerformed(evt);
            }
        });
        kepalaPanel.add(btPembayaran, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, 220, 40));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back_12955.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        kepalaPanel.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(995, 10, 60, 40));

        design.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ObatKepala.jpg"))); // NOI18N
        kepalaPanel.add(design, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        menuPanel.add(kepalaPanel, "card5");

        pembayaranPanel.setBackground(new java.awt.Color(255, 255, 255));
        pembayaranPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblBelanjaan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama Obat", "Kategori", "Bentuk Obat", "Jumlah Pembelian", "Harga"
            }
        ));
        jScrollPane1.setViewportView(tblBelanjaan);

        pembayaranPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 171, 1010, 280));

        jLabel89.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 40)); // NOI18N
        jLabel89.setText("List Total Pembelian Obat Anda");
        pembayaranPanel.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 48, 600, -1));

        jLabel16.setFont(new java.awt.Font("Perpetua", 0, 20)); // NOI18N
        jLabel16.setText("Masukkan Uang Anda: ");
        pembayaranPanel.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 500, 180, 20));

        hargaTotal.setFont(new java.awt.Font("Perpetua", 0, 23)); // NOI18N
        hargaTotal.setText("a");
        pembayaranPanel.add(hargaTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 460, 210, 20));
        pembayaranPanel.add(uang, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 500, 210, 30));

        jLabel36.setFont(new java.awt.Font("Perpetua", 0, 20)); // NOI18N
        jLabel36.setText("Total Pembelian:");
        pembayaranPanel.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 460, 200, 20));

        jButton1.setFont(new java.awt.Font("Perpetua", 0, 24)); // NOI18N
        jButton1.setText("Bayar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        pembayaranPanel.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 540, 210, -1));

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back_12955.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        pembayaranPanel.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 10, 60, 40));

        menuPanel.add(pembayaranPanel, "card6");

        kakiPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel88.setText("400 MG");
        kakiPanel.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 130, 20));

        aleva.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        aleva.setText("Aleve Naproxen Sodium");
        kakiPanel.add(aleva, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 140, 20));

        ibuProfen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ibuProfen.setText("Ibuprofen");
        kakiPanel.add(ibuProfen, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 140, 20));

        Diclofenac.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Diclofenac.setText("Diclofenac");
        kakiPanel.add(Diclofenac, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, 130, 20));

        jLabel93.setText("0.5 MG BOX");
        kakiPanel.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 150, 70, -1));

        jLabel94.setText("220 MG");
        kakiPanel.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 80, -1));

        recofar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        recofar.setText("Recolfar");
        kakiPanel.add(recofar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 140, 20));

        mp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mp.setText("Methylprednisolone");
        kakiPanel.add(mp, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 130, 30));

        al.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        al.setText("Allopurinol");
        kakiPanel.add(al, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 340, 140, 20));

        ac.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ac.setText("Aclonac");
        kakiPanel.add(ac, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 330, 140, 30));

        ce.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ce.setText("Celebrex");
        kakiPanel.add(ce, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 330, 150, 30));

        as.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        as.setText("Aspirin");
        kakiPanel.add(as, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, 140, 30));

        celeco.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        celeco.setText("Celecoxib");
        kakiPanel.add(celeco, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 550, 160, 30));

        cc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cc.setText("COUNTERPAIN CREAM");
        kakiPanel.add(cc, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 550, 140, 30));

        hi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        hi.setText("   Hi-D 5000");
        kakiPanel.add(hi, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 560, 140, 20));

        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel104.setText("4 MG");
        kakiPanel.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 360, -1, -1));

        jLabel105.setText("300 MG");
        kakiPanel.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 360, -1, -1));

        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel106.setText("30 G");
        kakiPanel.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 350, 140, 30));

        jLabel107.setText("100 MG");
        kakiPanel.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, -1, -1));

        jLabel108.setText("100 MG");
        kakiPanel.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 570, 80, 30));

        jLabel109.setText("200 MG");
        kakiPanel.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 580, -1, -1));

        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("60 G");
        kakiPanel.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 570, 120, 20));

        jLabel111.setText("30 TABLET");
        kakiPanel.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 580, -1, -1));

        jLabel112.setText("Rp. 160.000");
        kakiPanel.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 170, -1, -1));

        jLabel113.setText("Rp. 16.000");
        kakiPanel.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 170, -1, -1));

        jLabel114.setText("Rp. 400.000");
        kakiPanel.add(jLabel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, -1, -1));

        jLabel115.setText("Rp. 263.000");
        kakiPanel.add(jLabel115, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 70, -1));

        jLabel116.setText("Rp. 110.000");
        kakiPanel.add(jLabel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 380, -1, -1));

        jLabel117.setText("Rp. 30.000");
        kakiPanel.add(jLabel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 370, 70, 20));

        jLabel118.setText("Rp. 45.000");
        kakiPanel.add(jLabel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 380, -1, -1));

        jLabel119.setText("Rp. 35.000");
        kakiPanel.add(jLabel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 380, -1, -1));

        jLabel120.setText("Rp. 120.000");
        kakiPanel.add(jLabel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 600, -1, -1));

        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel121.setText("Rp. 69.500");
        kakiPanel.add(jLabel121, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 590, 90, 20));

        jLabel122.setText("Rp. 65.000");
        kakiPanel.add(jLabel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 600, -1, -1));

        jLabel123.setText("Rp. 55.000");
        kakiPanel.add(jLabel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 600, -1, -1));

        hiD.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        hiD.setText("0");
        kakiPanel.add(hiD, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 630, 30, 30));

        p13.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p13.setText("+");
        kakiPanel.add(p13, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 630, 40, 30));

        m13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m13.setText("-");
        kakiPanel.add(m13, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 630, 40, 30));

        aleveNaproxen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aleveNaproxen.setText("0");
        kakiPanel.add(aleveNaproxen, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 30, 30));

        p26.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p26.setText("+");
        kakiPanel.add(p26, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 40, 30));

        ibuprofen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ibuprofen.setText("0");
        kakiPanel.add(ibuprofen, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 200, 30, 30));

        diclofenac.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        diclofenac.setText("0");
        kakiPanel.add(diclofenac, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 30, 30));

        recolfar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        recolfar.setText("0");
        kakiPanel.add(recolfar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 30, 30));

        celebrex.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        celebrex.setText("0");
        kakiPanel.add(celebrex, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 420, 30, 30));

        aclonac.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aclonac.setText("0");
        kakiPanel.add(aclonac, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 30, 30));

        allopurinol.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        allopurinol.setText("0");
        kakiPanel.add(allopurinol, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 420, 30, 30));

        methylprednisolone.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        methylprednisolone.setText("0");
        kakiPanel.add(methylprednisolone, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 30, 30));

        aspirin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        aspirin.setText("0");
        kakiPanel.add(aspirin, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 30, 30));

        celecoxib.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        celecoxib.setText("0");
        kakiPanel.add(celecoxib, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 630, 30, 30));

        counterpain.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        counterpain.setText("0");
        kakiPanel.add(counterpain, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 630, 30, 30));

        p27.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p27.setText("+");
        kakiPanel.add(p27, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 40, 30));

        p28.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p28.setText("+");
        kakiPanel.add(p28, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 200, 40, 30));

        p29.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p29.setText("+");
        kakiPanel.add(p29, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 200, 40, 30));

        p30.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p30.setText("+");
        kakiPanel.add(p30, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, 40, 30));

        p31.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p31.setText("+");
        kakiPanel.add(p31, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 420, 40, 30));

        p32.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p32.setText("+");
        kakiPanel.add(p32, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 420, 40, 30));

        p33.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p33.setText("+");
        kakiPanel.add(p33, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, 40, 30));

        p34.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p34.setText("+");
        kakiPanel.add(p34, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 630, 40, 30));

        p35.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p35.setText("+");
        kakiPanel.add(p35, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 630, 40, 30));

        p36.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        p36.setText("+");
        kakiPanel.add(p36, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 630, 40, 30));

        m26.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m26.setText("-");
        kakiPanel.add(m26, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 40, 30));

        m27.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m27.setText("-");
        kakiPanel.add(m27, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 40, 30));

        m28.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m28.setText("-");
        kakiPanel.add(m28, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, 40, 30));

        m29.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m29.setText("-");
        kakiPanel.add(m29, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 200, 40, 30));

        m30.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m30.setText("-");
        kakiPanel.add(m30, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 40, 30));

        m31.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m31.setText("-");
        kakiPanel.add(m31, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 420, 40, 30));

        m32.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m32.setText("-");
        kakiPanel.add(m32, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 40, 30));

        m33.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m33.setText("-");
        kakiPanel.add(m33, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 40, 30));

        m34.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m34.setText("-");
        kakiPanel.add(m34, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 630, 40, 30));

        m35.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m35.setText("-");
        kakiPanel.add(m35, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 630, 40, 30));

        m36.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        m36.setText("-");
        kakiPanel.add(m36, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 630, 40, 30));

        jLabel124.setText("50 MG");
        kakiPanel.add(jLabel124, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 150, -1, -1));
        kakiPanel.add(jLabel125, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        btPembayaran1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/keranjang.png"))); // NOI18N
        btPembayaran1.setText("Masukkan Keranjang");
        btPembayaran1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPembayaran1ActionPerformed(evt);
            }
        });
        kakiPanel.add(btPembayaran1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, 220, 40));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back_12955.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        kakiPanel.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(995, 10, 60, 40));

        jLabel163.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/UI BeliObat Kaki.jpg"))); // NOI18N
        kakiPanel.add(jLabel163, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        menuPanel.add(kakiPanel, "card7");

        getContentPane().add(menuPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(251, -5, 1070, 690));

        jPanel1.setBackground(new java.awt.Color(153, 255, 204));

        btCekKesehatan.setBackground(new java.awt.Color(153, 255, 204));
        btCekKesehatan.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btCekKesehatan.setText("Cek Kesehatan");
        btCekKesehatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCekKesehatanActionPerformed(evt);
            }
        });

        btBeliObat.setBackground(new java.awt.Color(153, 255, 204));
        btBeliObat.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btBeliObat.setText("Beli Obat");
        btBeliObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBeliObatActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Man.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Sitka Small", 0, 18)); // NOI18N
        jLabel2.setText("WELCOME !");

        namaAcc.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        namaAcc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        namaAcc.setText("Yasin Alfi Yahya");

        btKeluar.setBackground(new java.awt.Color(153, 255, 204));
        btKeluar.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btKeluar.setText("Keluar");
        btKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btKeluarActionPerformed(evt);
            }
        });

        btCredit.setBackground(new java.awt.Color(153, 255, 204));
        btCredit.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btCredit.setText("Credit");
        btCredit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCreditActionPerformed(evt);
            }
        });

        btHome.setBackground(new java.awt.Color(153, 255, 204));
        btHome.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btHome.setText("Home");
        btHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btHomeActionPerformed(evt);
            }
        });

        btBiodata.setBackground(new java.awt.Color(153, 255, 204));
        btBiodata.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        btBiodata.setText("Biodata");
        btBiodata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBiodataActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btCekKesehatan, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btBiodata, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btHome, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btBeliObat, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(namaAcc, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel1)
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(namaAcc, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27)
                .addComponent(btHome, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btBeliObat, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btCekKesehatan, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btBiodata, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btKeluarActionPerformed
        int input = JOptionPane.showConfirmDialog(null, "Anda yakin ingin keluar?", "Pesan Konfirmasi", JOptionPane.YES_NO_OPTION);
        if(input == 0){
            TesterProject login = new TesterProject();
            login.setVisible(true);
            login.pack();
            login.setLocationRelativeTo(null);
            login.setDefaultCloseOperation(HalamanUtama.EXIT_ON_CLOSE);
            this.dispose();            
        }
    }//GEN-LAST:event_btKeluarActionPerformed

    private void btHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btHomeActionPerformed
        // TODO add your handling code here:
        Interface.setHome(tempU.getText(), tempPass.getText());
        kosongkan();
        this.dispose();
    }//GEN-LAST:event_btHomeActionPerformed

    private void btBiodataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBiodataActionPerformed
        // TODO add your handling code here:
        kosongkan();
        Interface.setAbout(tempU.getText(), tempPass.getText());
        this.dispose();
    }//GEN-LAST:event_btBiodataActionPerformed

    private void btMataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMataActionPerformed
        // TODO add your handling code here:
        menuPanel.removeAll();
        
        menuPanel.add(mataPanel);
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_btMataActionPerformed

    /**
     * untuk mengosongkan kembali data pembelian obat dari user
     */
    public void kosongkan(){
        for(int a = 0; a < tx.length; a++){
            if(!tx[a].getText().equals("0")){
            for(int i = 0; i < tx.length; i++){
               tx[i].setText("0");
            }
            break;
            }  
        }
    }
    
    /**
     * untuk kembali ke Panel pembelian obat
     */
    public void setObatBack(){
        menuPanel.removeAll();
        menuPanel.add(pembelianObat);
        menuPanel.repaint();
        menuPanel.revalidate();
    }
    
    private void btBeliObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBeliObatActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
        model.setRowCount(0);
        kosongkan();
        setObatBack();
    }//GEN-LAST:event_btBeliObatActionPerformed

    private void btMulutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMulutActionPerformed
        // TODO add your handling code here:
        menuPanel.removeAll();
        menuPanel.add(mulutPanel);
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_btMulutActionPerformed

    private void btKepalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btKepalaActionPerformed
        // TODO add your handling code here:
        menuPanel.removeAll();
        menuPanel.add(kepalaPanel);
        menuPanel.repaint();
        menuPanel.revalidate();

    }//GEN-LAST:event_btKepalaActionPerformed

    private void btPembayaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPembayaranActionPerformed
        // TODO add your handling code here:
        try{
            DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
            belanjaObat();
            String[][] row = new String[obatDibeli.size()][5];
            for(int i = 0; i < obatDibeli.size(); i++){
                row[i][0] = obatDibeli.get(i).getNamaObat();
                row[i][1] = "Obat" + obatDibeli.get(i).getBagianPenyakit();
                row[i][2] = obatDibeli.get(i).getBentukObat();
                row[i][3] = ""+obatDibeli.get(i).getBanyakBarang();
                row[i][4] = ""+obatDibeli.get(i).getHarga();

                model.addRow(new Object[]
                    {row[i][0], row[i][1], row[i][2], row[i][3], row[i][4]}
                );
            }

            double tempHarga = 0;
            for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                tempHarga += Double.parseDouble(""+tblBelanjaan.getValueAt(i, 4));
            }

            hargaTotal.setText(""+tempHarga);
            obatDibeli.clear();
            menuPanel.removeAll();
            menuPanel.add(pembayaranPanel);
            menuPanel.repaint();
            menuPanel.revalidate();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Jumlah barang yang dimasukkan harus berupa angka!", "Pesan Error", JOptionPane.ERROR_MESSAGE);   
        }
    }//GEN-LAST:event_btPembayaranActionPerformed

    private void btKakiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btKakiActionPerformed
        // TODO add your handling code here:
        menuPanel.removeAll();
        menuPanel.add(kakiPanel);
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_btKakiActionPerformed

    private void count14KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_count14KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_count14KeyReleased

    private void btCekKesehatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCekKesehatanActionPerformed
        // TODO add your handling code here:
        kosongkan();
        CekSehat sehat = new CekSehat();
        sehat.setVisible(true);
        sehat.tempU.setText(tempU.getText());
        sehat.tempPass.setText(tempPass.getText());
        this.dispose();
    }//GEN-LAST:event_btCekKesehatanActionPerformed

    private void btCreditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCreditActionPerformed
        // TODO add your handling code here:
        kosongkan();
        Credit credit = new Credit();
        credit.setVisible(true);
        credit.tempU.setText(tempU.getText());
        credit.tempPass.setText(tempPass.getText());
        this.dispose();
    }//GEN-LAST:event_btCreditActionPerformed

    private void btPembayaran1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPembayaran1ActionPerformed
        // TODO add your handling code here:
        try{
            DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
            belanjaObat();
            String[][] row = new String[obatDibeli.size()][5];
            for(int i = 0; i < obatDibeli.size(); i++){
                row[i][0] = obatDibeli.get(i).getNamaObat();
                row[i][1] = "Obat" + obatDibeli.get(i).getBagianPenyakit();
                row[i][2] = obatDibeli.get(i).getBentukObat();
                row[i][3] = ""+obatDibeli.get(i).getBanyakBarang();
                row[i][4] = ""+obatDibeli.get(i).getHarga();

                model.addRow(new Object[]
                    {row[i][0], row[i][1], row[i][2], row[i][3], row[i][4]}
                );
            }

            double tempHarga = 0;
            for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                tempHarga += Double.parseDouble(""+tblBelanjaan.getValueAt(i, 4));
            }
            hargaTotal.setText(""+tempHarga);
            obatDibeli.clear();
            menuPanel.removeAll();
            menuPanel.add(pembayaranPanel);
            menuPanel.repaint();
            menuPanel.revalidate();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Jumlah barang yang dimasukkan harus berupa angka!", "Pesan Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btPembayaran1ActionPerformed

    private void btPembayaran2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPembayaran2ActionPerformed
        // TODO add your handling code here:
        try{
            DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
            belanjaObat();
            String[][] row = new String[obatDibeli.size()][5];
            for(int i = 0; i < obatDibeli.size(); i++){
                row[i][0] = obatDibeli.get(i).getNamaObat();
                row[i][1] = "Obat" + obatDibeli.get(i).getBagianPenyakit();
                row[i][2] = obatDibeli.get(i).getBentukObat();
                row[i][3] = ""+obatDibeli.get(i).getBanyakBarang();
                row[i][4] = ""+obatDibeli.get(i).getHarga();

                model.addRow(new Object[]
                    {row[i][0], row[i][1], row[i][2], row[i][3], row[i][4]}
                );
            }
            double tempHarga = 0;
            for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                tempHarga += Double.parseDouble(""+tblBelanjaan.getValueAt(i, 4));
            }
            hargaTotal.setText(""+tempHarga);
            obatDibeli.clear();
            menuPanel.removeAll();
            menuPanel.add(pembayaranPanel);
            menuPanel.repaint();
            menuPanel.revalidate();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Jumlah barang yang dimasukkan harus berupa angka!", "Pesan Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btPembayaran2ActionPerformed

    private void btPembayaran3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPembayaran3ActionPerformed
        // TODO add your handling code here:
        try{
            DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
            belanjaObat();
            String[][] row = new String[obatDibeli.size()][5];
            for(int i = 0; i < obatDibeli.size(); i++){
                row[i][0] = obatDibeli.get(i).getNamaObat();
                row[i][1] = "Obat" + obatDibeli.get(i).getBagianPenyakit();
                row[i][2] = obatDibeli.get(i).getBentukObat();
                row[i][3] = ""+obatDibeli.get(i).getBanyakBarang();
                row[i][4] = ""+obatDibeli.get(i).getHarga();

                model.addRow(new Object[]
                    {row[i][0], row[i][1], row[i][2], row[i][3], row[i][4]}
                );
            }

            double tempHarga = 0;
            for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                tempHarga += Double.parseDouble(""+tblBelanjaan.getValueAt(i, 4));
            }

            hargaTotal.setText(""+tempHarga);
            obatDibeli.clear();
            menuPanel.removeAll();
            menuPanel.add(pembayaranPanel);
            menuPanel.repaint();
            menuPanel.revalidate();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Jumlah barang yang dimasukkan harus berupa angka!", "Pesan Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btPembayaran3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        ArrayList<Integer> id_obat = new ArrayList<Integer>();
        String formattedDate = "";
        if(uang.getText().equals("")){
             JOptionPane.showMessageDialog(null, "Masukan Uang Anda", "Warning", JOptionPane.WARNING_MESSAGE);
        }
//        else if(Double.parseDouble(uang.getText()) >= Double.parseDouble(hargaTotal.getText())){
        else{    
            boolean patokan = true;
                for(int i = 0; i < uang.getText().length(); i++){
                if(uang.getText().charAt(i) >= '0' && uang.getText().charAt(i) <= '9'){
                    patokan = true;
                }
                else {
                    patokan = false;
                    break;
                }
            }
            if(patokan){
                if(Double.parseDouble(uang.getText()) >= Double.parseDouble(hargaTotal.getText())){
                    ArrayList<Integer> stok = new ArrayList<Integer>();
                    try{
                       String select = "SELECT * FROM obat WHERE NAMAOBAT=?";
                       connect.pst = connect.con.prepareStatement(select);
                       for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                            int tempTotal = Integer.parseInt(""+tblBelanjaan.getValueAt(i, 3));
                            String tempObat = (""+tblBelanjaan.getValueAt(i, 0));
                            connect.pst.setString(1, tempObat);
                            connect.rs = connect.pst.executeQuery();
                            if(connect.rs.next()){
                                stok.add(connect.rs.getInt("STOK"));
                                id_obat.add(connect.rs.getInt("ID_OBAT"));
                            }
                       }
                    try{
                        String sql = "UPDATE obat SET STOK=? WHERE NAMAOBAT=?";
                        connect.con = getKoneksi();
                        for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                            int tempTotal = Integer.parseInt(""+tblBelanjaan.getValueAt(i, 3));
                            String tempObat = (""+tblBelanjaan.getValueAt(i, 0));
                            connect.pst = connect.con.prepareStatement(sql);
                            connect.pst.setInt(1, stok.get(i)-tempTotal);
                            connect.pst.setString(2, tempObat);
                            connect.pst.executeUpdate();
                        }
                    }catch(Exception e){
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Pesan Error", JOptionPane.ERROR_MESSAGE);
                    }
                    }catch(SQLException e){
                       JOptionPane.showMessageDialog(null, e.getMessage(), "Pesan Error", JOptionPane.ERROR_MESSAGE);
                    }
                    try{
                        LocalDateTime myDateObj = LocalDateTime.now();            
                        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH-mm-ss");
                        formattedDate = ""+ myDateObj.format(myFormatObj);

                        String tempat = JOptionPane.showInputDialog(null, "Tempat Anda Ingin Menyimpan Struk :");
                        PrintWriter wr = new PrintWriter(tempat + formattedDate + " " + namaAcc.getText() +  ".txt", "UTF-8");
                        wr.println("\t\t   Selamat Datang\n\t\t     Di Aplikasi\n\t\t    Yuk Sehat Yuk");
                        wr.println("---------------------------------------------------");
                        wr.println("Nama Pembeli\t\t: " + namaAcc.getText());
                        wr.println("Tanggal dan Waktu\t: " + formattedDate);
                        wr.println("---------------------------------------------------");
                        for(int i = 0; i < tblBelanjaan.getRowCount(); i++){
                            String tempObat = (""+ tblBelanjaan.getValueAt(i, 0));
                            int jumlahObat = Integer.parseInt("" + tblBelanjaan.getValueAt(i, 3));
                            double hargaObat = Double.parseDouble("" + tblBelanjaan.getValueAt(i, 4));
                            wr.println(tempObat + "\t\t" + jumlahObat + "\tRp. " + hargaObat);
                        }
                        wr.println("---------------------------------------------------");
                        wr.println("Total Harga\t\t:\tRp. " + hargaTotal.getText());
                        long kembalian = (long)(Double.parseDouble(uang.getText()) - Double.parseDouble(hargaTotal.getText()));
                        wr.println("Uang Anda\t\t:\tRp. " + uang.getText());
                        wr.println("Kembalian Uang\t\t:\tRp. " + kembalian);
                        wr.println("     Terima Kasih & Selamat Berbelanja Kembali\n\t\tSemoga Selalu Sehat\n\t\t    INFO LENGKAP\n\t    Programmer: Yasin Alfi Yahya\n\t     Basis Data: Muhammad Azhari\n\t        Design: Muhammad Rohfi\n\t\t  Project Akhir PBO\n\t\t  Universitas Yarsi");
                        wr.close();
                        uang.setText("");
                        hargaTotal.setText("");
                        JOptionPane.showMessageDialog(null,"Struk Berhasil Disimpan");

                        Interface.setHome(tempU.getText(), tempPass.getText());
                        this.dispose();

                    }catch(Exception e){
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Pesan Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else JOptionPane.showMessageDialog(null, "Uang Anda Kurang", "Warning", JOptionPane.WARNING_MESSAGE);
            }else JOptionPane.showMessageDialog(null, "Masukan angka bilangan bulat", "Warning", JOptionPane.WARNING_MESSAGE);
        }
        for(int i = 0; i < tx.length; i++){ // untuk mengembalikan semua jTextfield menjadi 0 
               tx[i].setText("0");
            }
        
        try{ // untuk data base struk
            ArrayList<String> barang = new ArrayList<String>();
            String sql = "INSERT INTO struk (username, tanggal, id_obat) VALUES(?,?,?)"; // insert ke data base tabel struk
            connect.pst = connect.con.prepareStatement(sql);    
            for(int i = 0; i < id_obat.size(); i++){ // mengulang sebanyak obat yang di beli
                connect.pst.setString(1, tempU.getText()); // mengambil nama user dari tabel akun
                connect.pst.setString(2, formattedDate); // mengambil tanggal
                connect.pst.setInt(3, id_obat.get(i)); // mengabil id_obat dari tabel obat
                connect.pst.executeUpdate();
            }
        }catch(Exception exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:z
        DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
        model.setRowCount(0);
        setObatBack();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
        model.setRowCount(0);
        setObatBack();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
        model.setRowCount(0);
        setObatBack();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
        model.setRowCount(0);
        setObatBack();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tblBelanjaan.getModel();
        model.setRowCount(0);
        setObatBack();
    }//GEN-LAST:event_jButton6ActionPerformed
    
    /**
     * method utama kelas
     * @param args
     */
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PembelianObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PembelianObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PembelianObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PembelianObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PembelianObat().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Diclofenac;
    private javax.swing.JLabel LbAlconTears;
    private javax.swing.JLabel LbAlletrolCompositum;
    private javax.swing.JLabel LbCCenfresh;
    private javax.swing.JLabel LbCFloxa;
    private javax.swing.JLabel LbCHyalub;
    private javax.swing.JLabel LbCMoncort;
    private javax.swing.JLabel LbCTobroson;
    private javax.swing.JLabel LbErlamycetin;
    private javax.swing.JLabel LbInstoDryEyes;
    private javax.swing.JLabel LbInstoRegularEyeDrops;
    private javax.swing.JLabel LbOhtoCoolEye;
    private javax.swing.JLabel LbVisineExtraEye;
    private javax.swing.JLabel ac;
    private javax.swing.JTextField aclonac;
    private javax.swing.JLabel ademSari;
    private javax.swing.JLabel al;
    private javax.swing.JTextField alconTears;
    private javax.swing.JLabel aleva;
    private javax.swing.JTextField aleveNaproxen;
    private javax.swing.JTextField alletrol;
    private javax.swing.JTextField allopurinol;
    private javax.swing.JLabel aloclair;
    private javax.swing.JLabel antalgin;
    private javax.swing.JLabel as;
    private javax.swing.JLabel aspilets;
    private javax.swing.JTextField aspirin;
    private javax.swing.JLabel betadine;
    private javax.swing.JLabel bintangToedjoe;
    private javax.swing.JLabel biogesic;
    private javax.swing.JLabel bodrexExtra;
    private javax.swing.JButton btBeliObat;
    private javax.swing.JButton btBiodata;
    private javax.swing.JButton btCekKesehatan;
    private javax.swing.JButton btCredit;
    private javax.swing.JButton btHome;
    private javax.swing.JButton btKaki;
    private javax.swing.JButton btKeluar;
    private javax.swing.JButton btKepala;
    private javax.swing.JButton btMata;
    private javax.swing.JButton btMulut;
    private javax.swing.JButton btPembayaran;
    private javax.swing.JButton btPembayaran1;
    private javax.swing.JButton btPembayaran2;
    private javax.swing.JButton btPembayaran3;
    private javax.swing.JTextField cCenfresh;
    private javax.swing.JTextField cFloxa;
    private javax.swing.JTextField cHyalub;
    private javax.swing.JTextField cMoncort;
    private javax.swing.JTextField cTobroson;
    private javax.swing.JLabel cc;
    private javax.swing.JLabel ce;
    private javax.swing.JTextField celebrex;
    private javax.swing.JLabel celeco;
    private javax.swing.JTextField celecoxib;
    private javax.swing.JLabel cooling;
    public javax.swing.JTextField count14;
    private javax.swing.JTextField count15;
    private javax.swing.JTextField count16;
    private javax.swing.JTextField count17;
    private javax.swing.JTextField count18;
    private javax.swing.JTextField count19;
    private javax.swing.JTextField count20;
    private javax.swing.JTextField count21;
    private javax.swing.JTextField count22;
    private javax.swing.JTextField count23;
    private javax.swing.JTextField count24;
    private javax.swing.JTextField count25;
    private javax.swing.JTextField counterpain;
    private javax.swing.JLabel degirol;
    private javax.swing.JLabel design;
    private javax.swing.JTextField diclofenac;
    private javax.swing.JTextField erlamycetin;
    private javax.swing.JLabel hargaTotal;
    private javax.swing.JLabel hi;
    private javax.swing.JTextField hiD;
    private javax.swing.JLabel ibuProfen;
    private javax.swing.JTextField ibuprofen;
    private javax.swing.JTextField instoDropEye;
    private javax.swing.JTextField instoDryEye;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jesscool;
    private javax.swing.JPanel kakiPanel;
    private javax.swing.JPanel kepalaPanel;
    private javax.swing.JLabel larutan;
    private javax.swing.JLabel listerine;
    private javax.swing.JButton m1;
    private javax.swing.JButton m10;
    private javax.swing.JButton m11;
    private javax.swing.JButton m12;
    private javax.swing.JButton m13;
    private javax.swing.JButton m14;
    private javax.swing.JButton m15;
    private javax.swing.JButton m16;
    private javax.swing.JButton m17;
    private javax.swing.JButton m18;
    private javax.swing.JButton m19;
    private javax.swing.JButton m2;
    private javax.swing.JButton m20;
    private javax.swing.JButton m21;
    private javax.swing.JButton m22;
    private javax.swing.JButton m23;
    private javax.swing.JButton m24;
    private javax.swing.JButton m25;
    private javax.swing.JButton m26;
    private javax.swing.JButton m27;
    private javax.swing.JButton m28;
    private javax.swing.JButton m29;
    private javax.swing.JButton m3;
    private javax.swing.JButton m30;
    private javax.swing.JButton m31;
    private javax.swing.JButton m32;
    private javax.swing.JButton m33;
    private javax.swing.JButton m34;
    private javax.swing.JButton m35;
    private javax.swing.JButton m36;
    private javax.swing.JButton m37;
    private javax.swing.JButton m38;
    private javax.swing.JButton m39;
    private javax.swing.JButton m4;
    private javax.swing.JButton m40;
    private javax.swing.JButton m41;
    private javax.swing.JButton m42;
    private javax.swing.JButton m43;
    private javax.swing.JButton m44;
    private javax.swing.JButton m45;
    private javax.swing.JButton m46;
    private javax.swing.JButton m47;
    private javax.swing.JButton m48;
    private javax.swing.JButton m5;
    private javax.swing.JButton m6;
    private javax.swing.JButton m7;
    private javax.swing.JButton m8;
    private javax.swing.JButton m9;
    private javax.swing.JPanel mataPanel;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JTextField methylprednisolone;
    private javax.swing.JLabel mp;
    private javax.swing.JPanel mulutPanel;
    public javax.swing.JLabel namaAcc;
    private javax.swing.JTextField ohtoCoolEye;
    private javax.swing.JLabel oskadon;
    private javax.swing.JButton p1;
    private javax.swing.JButton p10;
    private javax.swing.JButton p11;
    private javax.swing.JButton p12;
    private javax.swing.JButton p13;
    public javax.swing.JButton p14;
    private javax.swing.JButton p15;
    private javax.swing.JButton p16;
    private javax.swing.JButton p17;
    private javax.swing.JButton p18;
    private javax.swing.JButton p19;
    private javax.swing.JButton p2;
    private javax.swing.JButton p20;
    protected javax.swing.JButton p21;
    private javax.swing.JButton p22;
    private javax.swing.JButton p23;
    private javax.swing.JButton p24;
    private javax.swing.JButton p25;
    private javax.swing.JButton p26;
    private javax.swing.JButton p27;
    private javax.swing.JButton p28;
    private javax.swing.JButton p29;
    private javax.swing.JButton p3;
    private javax.swing.JButton p30;
    private javax.swing.JButton p31;
    private javax.swing.JButton p32;
    private javax.swing.JButton p33;
    private javax.swing.JButton p34;
    private javax.swing.JButton p35;
    private javax.swing.JButton p36;
    private javax.swing.JButton p37;
    private javax.swing.JButton p38;
    private javax.swing.JButton p39;
    private javax.swing.JButton p4;
    private javax.swing.JButton p40;
    private javax.swing.JButton p41;
    private javax.swing.JButton p42;
    private javax.swing.JButton p43;
    private javax.swing.JButton p44;
    private javax.swing.JButton p45;
    private javax.swing.JButton p46;
    private javax.swing.JButton p47;
    private javax.swing.JButton p48;
    private javax.swing.JButton p5;
    private javax.swing.JButton p6;
    private javax.swing.JButton p7;
    private javax.swing.JButton p8;
    private javax.swing.JButton p9;
    private javax.swing.JLabel panadolAnak;
    private javax.swing.JLabel panadolBiru;
    private javax.swing.JLabel panadolHijau;
    private javax.swing.JLabel panadolMerah;
    private javax.swing.JLabel paramex;
    private javax.swing.JPanel pembayaranPanel;
    private javax.swing.JPanel pembelianObat;
    private javax.swing.JLabel recofar;
    private javax.swing.JTextField recolfar;
    private javax.swing.JLabel saridon;
    private javax.swing.JLabel spTroches;
    private javax.swing.JLabel strepsilCool;
    private javax.swing.JLabel tantum;
    private javax.swing.JLabel tantumLozenges;
    public javax.swing.JTable tblBelanjaan;
    public javax.swing.JLabel tempPass;
    public javax.swing.JLabel tempU;
    private javax.swing.JTextField txAntalgin;
    private javax.swing.JTextField txAspilet;
    private javax.swing.JTextField txBintang7;
    private javax.swing.JTextField txBiogesic;
    private javax.swing.JTextField txBodrexExtra;
    private javax.swing.JTextField txOskadon;
    private javax.swing.JTextField txPanadolAnak;
    private javax.swing.JTextField txPanadolBiru;
    private javax.swing.JTextField txPanadolHijau;
    private javax.swing.JTextField txPanadolMerah;
    private javax.swing.JTextField txParamex;
    private javax.swing.JTextField txSaridon;
    private javax.swing.JTextField uang;
    private javax.swing.JTextField visine;
    // End of variables declaration//GEN-END:variables


}
