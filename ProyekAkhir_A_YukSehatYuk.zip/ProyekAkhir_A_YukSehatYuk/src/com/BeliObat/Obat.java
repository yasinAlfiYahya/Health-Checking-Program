package com.BeliObat;

/**
 * kelas Obat
 * @author User
 */
public class Obat {
    private String namaObat;
    private String bagianPenyakit; // mata, kepala, mulut, kaki
    private String bentuk; // cair, tablet
    private double harga;
    private int banyakBarang;
    
    /**
     * construtor dua parameter yang berfungsi untuk mengisi data bagian penyakit dan bentuk obat
     * @param bagPenyakit untuk bagian penyakit yang di pilih user
     * @param bentuk untuk bentuk obat yang di pilih user
     */
    public Obat(String bagPenyakit, String bentuk){
        this.setBagianPenyakit(bagPenyakit);
        this.setBentukObat(bentuk);
    }
    
    /**
     * untuk mengisi data bagian penyakit
     * @param bagPenyakit untuk bagian penyakit yang di pilih user
     */
    public Obat(String bagPenyakit){
        this.setBagianPenyakit(bagPenyakit);
    }
    
    /**
     * cunstruktor empat parameter yang berfungsi untuk mengisi data nama obat, bentuk obat, banyak barang dan harga
     * @param namaObat untuk nama obat yang di pilih user
     * @param bentuk untuk bentuk obat yang di pilih user
     * @param banyakBarang untuk banyak barang yang di masukan user
     * @param harga untuk harga yang di masukan user
     */
    public Obat(String namaObat, String bentuk, int banyakBarang, double harga){
        this.setNamaObat(namaObat);
        this.setBentukObat(bentuk);
        this.setBanyakBarang(banyakBarang);
        this.setHarga(harga);
    }
    
    /**
     * untuk mengisi data nama obat
     * @param namaObat untuk nama obat yang di pilih user
     */
    public void setNamaObat(String namaObat){
        this.namaObat = namaObat;
    }
    
    /**
     * untuk mengisi data harga
     * @param harga untuk harga yang dimasukan user
     */
    public void setHarga(double harga){
        this.harga = harga * getBanyakBarang();
    }
    
    /**
     * untuk mengisi data bagian penyakit
     * @param bagPenyakit untuk bagian penyakit yang di pilihuser
     */
    public void setBagianPenyakit(String bagPenyakit){
        this.bagianPenyakit = bagPenyakit;
    }
    
    /**
     * untuk mengisi data bentuk obat
     * @param bentukObat untuk bentuk obat yang di pilih user
     */
    public void setBentukObat(String bentukObat){
        this.bentuk = bentukObat;
    }
    
    /**
     * untuk mengisi data banyak barang
     * @param banyakBarang untuk banyak barang yang di masukan user
     */
    public void setBanyakBarang(int banyakBarang){
        this.banyakBarang = banyakBarang;
    }
    
    /**
     * untuk mengembalikan data nama obat 
     * @return mengembalikan nama obat dari user bertipe string
     */
    public String getNamaObat(){
       return namaObat;
    }
    
    /**
     * untuk mengembalikan data harga
     * @return mengembalikan harga dari user bertipe double
     */
    public double getHarga(){
        return harga;
    }
    
    /**
     * untuk mengembalikan data bentuk obat
     * @return mengembalikan bentuk obat dari user bertipe string 
     */
    public String getBentukObat(){
        return bentuk;
    }
    
    /**
     * untuk mengembalikan data bagian penyakit
     * @return mengembalikan bagian penyakit dari user bertipe string
     */
    public String getBagianPenyakit(){
        return bagianPenyakit;
    }
    
    /**
     * untuk mengembalikan data banyak barang
     * @return mengembalikan banyak barang dari user bertipe int
     */
    public int getBanyakBarang(){
        return banyakBarang;
    }
    
}
