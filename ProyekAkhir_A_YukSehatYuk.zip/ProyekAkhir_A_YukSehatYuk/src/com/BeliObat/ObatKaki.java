/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.BeliObat;

/**
 * kelas Obat kaki meng-extend obat
 * @author User
 */
public class ObatKaki extends Obat {

    /**
     * memanggil construktor empat parameter di kelas obat
     * @param namaObat untuk nama obat yang di pilih user 
     * @param bentuk untuk bentuk obat yang di pilih user
     * @param banyakBarang untuk banyak barang yang di masukan user 
     * @param harga untuk harga yang di masukan user
     */
    public ObatKaki(String namaObat, String bentuk, int banyakBarang, double harga){
        super(namaObat, bentuk, banyakBarang, harga);
        super.setBagianPenyakit(" Kaki ");
        
    }
    
    /**
     * mengisi data bagian penyakit 
     * @param bagPenyakit untuk bagian penyakit yang di pilih user
     */
    @Override
    public void setBagianPenyakit(String bagPenyakit){
        super.setBagianPenyakit(bagPenyakit);
    }
}
