
package com.BeliObat;

/**
 * kelas Obat kepala yang meng-extend kelas Obat
 * @author User
 */
public class ObatKepala extends Obat{
    private double promo;    

    /**
     * memanggil construktor empat parameter dari kelas Obat
     * @param namaObat untuk nama obat yang di pilih user
     * @param bentuk untuk bentuk obat yang di pilih user
     * @param banyakBarang untuk banyak barang yang di masukan user
     * @param harga untuk harga yang di masukan user
     * @param promo untuk promo yang di dapatkan user
     */
    public ObatKepala(String namaObat, String bentuk, int banyakBarang, double harga, double promo){
        super(namaObat, bentuk, banyakBarang, harga);
        this.setPromo(promo);
        this.setBagianPenyakit(" Kepala ");
        super.setHarga(super.getHarga() - (super.getHarga()*getPromo())/100);
    }
    
    /**
     * memanggil construktor empat parameter dari kelas Obat
     * @param namaObat untuk nama obat yang di pilih user
     * @param bentuk untuk bentuk obat yang di pilih user
     * @param banyakBarang untuk banyak barang di masukan user
     * @param harga untuk harga yang di masukan user
     */
    public ObatKepala(String namaObat, String bentuk, int banyakBarang, double harga){
        super(namaObat, bentuk, banyakBarang, harga);
        this.setBagianPenyakit(" Kepala ");
    }
    
    /**
     * untuk mengisi data bagian penyakit
     * @param bagPenyakit untuk bagian penyakit yang di pilih user
     */
    @Override
    public void setBagianPenyakit(String bagPenyakit){
        bagPenyakit = " Kepala ";
        super.setBagianPenyakit(bagPenyakit);
    }
    
    /**
     * untuk mengisi data promo
     * @param promo untuk promo yang akan di dapatkan user
     */
    public void setPromo(double promo){
        this.promo = promo;
    }
    
    /**
     * untuk mengembalikan promo
     * @return mengembalikan promo yang di dapatkan user
     */
    public double getPromo(){
        return promo;
    }
}
