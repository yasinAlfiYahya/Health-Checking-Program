
package com.BeliObat;

/**
 * Kelas Obat Mulut yang meng-extend Kelas Obat
 * @author User
 */
public class ObatMulut extends Obat{
    
    /**
     * memanggil contruktor empat parameter dari kelas Obat
     * @param namaObat untuk nama obat yang di pilih user
     * @param bentuk untuk bentuk obat yang di pilih user
     * @param banyakBarang untuk banyak barang yang di masukan user
     * @param harga untuk harga yang di masukan user
     */
    public ObatMulut(String namaObat, String bentuk, int banyakBarang, double harga){
        super(namaObat, bentuk, banyakBarang, harga);
        super.setBagianPenyakit(" Mulut ");
        
    }
    
    /**
     * untuk mengisi data bagian penyakit
     * @param bagPenyakit untuk bagian penyakit yang di pilih user
     */
    @Override
    public void setBagianPenyakit(String bagPenyakit){
        super.setBagianPenyakit(bagPenyakit);
    }
    
}
