package com.Mulai;

import com.Login.TesterProject;
import javax.swing.JOptionPane;

/**
 * kelas tampilan awal meng-extends JFrame
 * @author User
 */
public class TamplianAwal extends javax.swing.JFrame {

    /**
     * untuk menampilkan gui dari kelas tampilan awal
     */
    public TamplianAwal() {
        initComponents();
        setVisible(true);
    }
    
    /**
     * untuk menggerakan proses loading 
     */
    public void jalan(){
        try { 
            for(int i = 0; i < 101; i++) {
                Thread.sleep(50); 
                TamplianAwal.lbl_loading.setText("" + i + "%"); 
                TamplianAwal.jProgressBar1.setValue(i); 
                if(i == 100) { 
                    TesterProject hu = new TesterProject();
                    setVisible(false);
                    hu.setVisible(true); 
                }
            }
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Loading Error!\nMessage: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lbl_loading = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        appName = new javax.swing.JLabel();
        appName1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_loading.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbl_loading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_loading.setText("Loading %");
        jPanel1.add(lbl_loading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 1000, 30));

        jProgressBar1.setBackground(new java.awt.Color(255, 255, 255));
        jProgressBar1.setForeground(new java.awt.Color(0, 153, 51));
        jPanel1.add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 440, 720, 30));

        appName.setBackground(new java.awt.Color(0, 153, 51));
        appName.setFont(new java.awt.Font("Segoe Script", 1, 36)); // NOI18N
        appName.setForeground(new java.awt.Color(0, 153, 255));
        appName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        appName.setText("Yuk Sehat Yuk");
        jPanel1.add(appName, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 1000, -1));

        appName1.setBackground(new java.awt.Color(0, 153, 51));
        appName1.setFont(new java.awt.Font("Segoe Script", 1, 36)); // NOI18N
        appName1.setForeground(new java.awt.Color(0, 153, 255));
        appName1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        appName1.setText("Selamat Datang di Aplikasi");
        jPanel1.add(appName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 1000, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/pict.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 150, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1000, 500));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * method utama kelas
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TamplianAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TamplianAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TamplianAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TamplianAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TamplianAwal();
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel appName;
    private javax.swing.JLabel appName1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JProgressBar jProgressBar1;
    public static javax.swing.JLabel lbl_loading;
    // End of variables declaration//GEN-END:variables
}
