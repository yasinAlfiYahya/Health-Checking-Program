/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Mulai;

import com.Login.TesterProject;
import javax.swing.JOptionPane;

/**
 * kelas Gerak
 * @author User
 */
public class Gerak {

    /**
     * method utama kelas
     * @param args
     */
    public static void main(String[] args) {
        
        TamplianAwal ta = new TamplianAwal(); 
        ta.setVisible(true); 
        
        try { 
            for(int i = 0; i < 101; i++) { 
                Thread.sleep(20); 
                TamplianAwal.lbl_loading.setText("" + i + "%"); 
                TamplianAwal.jProgressBar1.setValue(i); // Menge-set bar hingga 100
                if(i == 100) { 
                    ta.setVisible(false); 
                    TesterProject hu = new TesterProject();
                    hu.setVisible(true); 
                }
            }
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Loading Error!\nMessage: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
