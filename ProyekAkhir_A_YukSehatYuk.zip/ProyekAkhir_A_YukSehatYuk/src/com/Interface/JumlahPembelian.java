
package com.Interface;
import java.util.ArrayList;
import javax.swing.*;

/**
 * interface Jumlah Pembelian
 * @author User
 */
public interface JumlahPembelian {   

    /**
     * untuk mengumpukan obat yang di beli 
     */
    ArrayList<JLabel> obat = new ArrayList<>();

    /**
     * untuk mengumpulkan banyak barang yang di beli 
     */
    ArrayList<JTextField> banyakBarang = new ArrayList<>();
    
    /**
     * untuk mengisi data pembelian user 
     * @param btPlus button plus yang digunakan untuk user
     * @param tx nama obat 
     * @param btMinus button minus yang digunakan untuk user
     * @param lb input yang dimasukan user
     */
    default void setBanyakPembelian(JButton btPlus, JTextField tx, JButton btMinus, JLabel lb){
        banyakBarang.add(tx);
        obat.add(lb);
        
        btPlus.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                    tx.setText("" + (Integer.parseInt(tx.getText())+1));  
            }
        });
        
        btMinus.addActionListener((java.awt.event.ActionEvent evt) -> {
            if(Integer.parseInt(tx.getText()) <= 0){
                tx.setText("0");
            }else{
                tx.setText("" + (Integer.parseInt(tx.getText())-1));            
            }
        });
        
        tx.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                String regex = "[0-9]+";
                if(!tx.getText().matches(regex) && tx.getText().length() > 0){
                    JOptionPane.showMessageDialog(null, "Jumlah barang yang dimasukkan harus berupa angka!", "Pesan Error", JOptionPane.WARNING_MESSAGE);
                    tx.setText("0");
                }
            }
        });
    }
}
