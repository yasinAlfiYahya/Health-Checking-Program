package com.Interface;

/**
 * interface checking
 * @author User
 */
public interface Checking {

    /**
     * untuk mengecek nama
     * @param nama untuk nama yang dimasukan user
     * @return mengembalikan true or false
     */
    public boolean cekNama(String nama);

    /**
     * untuk mengecek password
     * @param password untuk password yang dimasukan user
     * @return mengembalikan true or false
     */
    public boolean cekPassword(String password);

    /**
     * untuk mengecek nomor hp
     * @param nomor untuk nomor hp yang dimasukan user
     * @return mengembalikan true or false
     */
    public boolean cekNomorHp(String nomor);

    /**
     * untuk mengecek email
     * @param email untuk email yang dimasukan user
     * @return mengembalikan true or false
     */
    public boolean cekEmail(String email);
}
