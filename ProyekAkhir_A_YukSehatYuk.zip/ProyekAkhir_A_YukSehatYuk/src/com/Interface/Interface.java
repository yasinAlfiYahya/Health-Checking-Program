package com.Interface;

import com.Home.HalamanUtama;
import com.Home.Tentang;
import com.KoneksiDB.Koneksi;
import static com.KoneksiDB.Koneksi.getKoneksi;
import com.Pendaftar.Pendaftar;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * interface Inteface 
 * @author User
 */
public interface Interface{

    /**
     * mendeklar connect dengan method koneksi
     */
    Koneksi connect = new Koneksi();

    /**
     * untuk mengisi data sesuai dengan usename dan password
     * @param u username yang dimasukan user
     * @param p password yang dimasukan user
     */
    public static void setAbout(String u, String p){
        String sql = "SELECT * from AKUN WHERE USERNAME=? and PASSWORD=? ";
        connect.con = getKoneksi();

        try{
            connect.pst = connect.con.prepareStatement(sql);
            connect.pst.setString(1, u);
            connect.pst.setString(2, p);
            connect.rs = connect.pst.executeQuery();

            if(connect.rs.next()){
                Pendaftar user = new Tentang(u, p); // Upcasting
                Tentang about = (Tentang) user; // Downcasting
                about.setVisible(true);
                about.txNama.setText(connect.rs.getString("NAMA_LENGKAP"));
                about.txNomorHp.setText(connect.rs.getString("NOMOR_HP"));
                about.txEmail.setText(connect.rs.getString("EMAIL"));
                about.txUsername.setText(connect.rs.getString("USERNAME"));
                about.txJenisKelamin.setText(connect.rs.getString("JenisKelamin"));
                about.tempPw.setText(p);
                about.tempUn.setText(u);                
                about.namaAcc.setText(connect.rs.getString("NAMA_LENGKAP"));
                //this.dispose();
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
    }
    
    /**
     * untuk mengisi data sesuai dengan username dan password
     * @param u username yang dimasukan user
     * @param p password yang dimasukan user
     */
    public static void setHome(String u, String p){
        String sql = "SELECT * from AKUN WHERE USERNAME=? and PASSWORD=? ";
        connect.con = getKoneksi();

        try{
            connect.pst = connect.con.prepareStatement(sql);
            connect.pst.setString(1, u);
            connect.pst.setString(2, p);
            connect.rs = connect.pst.executeQuery();

            if(connect.rs.next()){
                Pendaftar user = new HalamanUtama(u, p); // Upcasting
                HalamanUtama home = (HalamanUtama) user; // Downcasting
                home.setVisible(true);
                home.namaAkun.setText(connect.rs.getString("NAMA_LENGKAP"));
                home.tempU.setText(u);
                home.tempPass.setText(p);
                //this.dispose();
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
}
