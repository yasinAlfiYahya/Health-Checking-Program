Langkah-langkah import database dan menjalankan file executable jar:

1. Buat database baru dengan nama database: Pendaftar
2. Import file pendaftar.sql (ada didalam folder SQL) kedalam database yang baru dibuat
3. Jalankan jar yang ada di folder dist
4. Jika muncul pop up "Koneksi Gagal", cek kembali import database di phpmyadmin
5. Jika masih gagal, import ProyekAkhir_A_YukSehatYuk.zip melalui teks editor Netbeans 
dan klik run project
6. Untuk menyimpan struk, salin directory dimana anda ingin menyimpan struk tersebut ke dalam dialog input message dan tambahkan slash (\) di akhir directory. contoh (C:\Users\User\Documents\) akan masuk ke folder Documents.

Note: 
- Username database = root
- Password database = "" (tanpa password)

untuk melihat javadoc ada di file = dist -> javadoc -> index.html
Link Youtube tempat unggah video demo proyek akhir: https://youtu.be/YJ3BFfiLNhA

Kelompok YukSehatYuk
Yasin Alfi Yahya - 1402019131
Muhammad Rohfi - 1402019076
Muhammad Azhari - 1402019061
