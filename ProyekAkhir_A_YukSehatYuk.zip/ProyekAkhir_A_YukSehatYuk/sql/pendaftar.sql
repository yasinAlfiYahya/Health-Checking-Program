-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Jan 2021 pada 05.36
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pendaftar`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `USERNAME` varchar(20) NOT NULL,
  `NAMA_LENGKAP` varchar(30) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `NOMOR_HP` varchar(20) DEFAULT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `JenisKelamin` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`USERNAME`, `NAMA_LENGKAP`, `EMAIL`, `NOMOR_HP`, `PASSWORD`, `JenisKelamin`) VALUES
('azhari', 'Muhammad Azhari', 'azhari@pbo.com', '085713173217', '1234567890', 'Laki - Laki'),
('herika', 'Herika Hayurani', 'herika@pbo.com', '08787873431', '12345678', 'Perempuan'),
('melisa', 'Melisa Aulia', 'melisa@rohfi.com', '02192131311', '12345678', 'Perempuan'),
('muhammadrohfi', 'Muhammad Rohfi', 'rohfi@pbo.com', '081231321231', '1234567890', 'Laki - Laki'),
('nurul', 'Nurul', 'nurul@rohfi.com', '0891313123113', '12345678', 'Perempuan'),
('yasin', 'Yasin Alfi Yahya', 'yasin@pbo.co.id', '08181231281', '123456789', 'Laki - Laki');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bagianpenyakit`
--

CREATE TABLE `bagianpenyakit` (
  `ID_BagianPenyakit` int(2) NOT NULL,
  `AnggotaTubuh` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bagianpenyakit`
--

INSERT INTO `bagianpenyakit` (`ID_BagianPenyakit`, `AnggotaTubuh`) VALUES
(1, 'Kepala'),
(2, 'Mata'),
(3, 'Kaki'),
(4, 'Mulut');

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `ID_OBAT` int(11) NOT NULL,
  `NAMAOBAT` varchar(100) NOT NULL,
  `BERAT` varchar(20) DEFAULT NULL,
  `JENISOBAT` varchar(40) NOT NULL,
  `HARGA` int(11) NOT NULL,
  `ID_BAGIANPENYAKIT` int(11) NOT NULL,
  `STOK` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`ID_OBAT`, `NAMAOBAT`, `BERAT`, `JENISOBAT`, `HARGA`, `ID_BAGIANPENYAKIT`, `STOK`) VALUES
(100, 'PANADOL COLD-FLU', '500 mg', 'Tablet', 20000, 1, 30),
(101, 'PANADOL PARACETAMOL', '500 mg', 'Tablet', 20000, 1, 21),
(102, 'PANADOL EXTRA', '500 mg', 'Tablet', 19000, 1, 17),
(103, 'BODREX EXTRA', '300 mg', 'Tablet', 6500, 1, 39),
(104, 'PARAMEX', '250 mg', 'Tablet', 6500, 1, 59),
(105, 'PANADOL ANAK', '120 mg', 'Cair', 25000, 1, 24),
(106, 'SARIDON', ' 250 mg', 'Tablet', 7500, 1, 81),
(107, 'OSKADON', '500 mg', 'Tablet', 5200, 1, 31),
(108, 'BINTANG TOEDJOE', '275 mg', 'Tablet', 17000, 1, 38),
(109, 'ANTALGIN', '500 mg', 'Cair', 15700, 1, 116),
(110, 'ASPILETS', '80 mg', 'Cair', 15000, 1, 81),
(111, 'BIOGESIC', '500 mg', 'Tablet', 5200, 1, 91),
(200, 'ERLAMYCETIN SALEP', ' 3.5 gram', 'CAIR', 17000, 2, 21),
(201, 'Insto Regular Eye Drops', ' 15 ml', 'CAIR', 22000, 2, 28),
(202, 'INSTO DRY EYES', ' 7.5 ml', 'CAIR', 27000, 2, 37),
(203, 'OHTO COOL EYE', ' 7.5 ml', 'CAIR', 61000, 2, 28),
(204, 'C TOBROSON MINIDOSE', ' 0.5 ml', 'CAIR', 72400, 2, 42),
(205, 'ALCON TEARS NATURALE', ' 15 ml', 'CAIR', 22800, 2, 55),
(206, 'CENDO FLOXA MINIDOSE', ' 0.6 ml', 'CAIR', 55000, 2, 61),
(207, 'C CENFRESH MINIDOSE', ' 0.6 ml', 'CAIR', 78500, 2, 24),
(208, 'VISINE EXTRA EYE', ' 6 mg', 'TABLET', 80000, 2, 18),
(209, 'ALLETROL COMPOSITUM', ' 5 ml', 'CAIR', 15700, 2, 23),
(210, 'C HYALUB MINIDOSE', ' 0.6 ml', 'CAIR', 21000, 2, 49),
(211, 'C NONCORT MINIDOSE ', ' 0.6 ml', 'CAIR', 11000, 2, 100),
(300, 'Aleve Naproxen Sodium', '220 MG', 'Tablet', 263000, 3, 29),
(301, 'Ibuprofen', '400 MG', 'Tablet', 400000, 3, 5),
(302, 'Diclofenac', '50 MG', 'Tablet', 16000, 3, 13),
(303, 'Recolfar', '0.5 MG BOX', 'Tablet', 160000, 3, 14),
(304, 'Celecoxib', '200 MG', 'Tablet', 65000, 3, 8),
(305, 'Methylprednisolone', '4 MG', 'Tablet', 35000, 3, 10),
(306, 'COUNTERPAIN CREAM', '60 G', 'Tablet', 69500, 3, 17),
(307, '   Hi-D 5000', '30 Tablet', 'Tablet', 120000, 3, 18),
(308, 'Allopurinol', '300 Mg', 'Obat Kaki', 45000, 3, 18),
(309, 'Aclonac', '30 G', 'Obat Kaki', 30000, 3, 49),
(310, 'Celebrex', '100 Mg', 'Obat Kaki', 110000, 3, 26),
(311, 'Aspirin', '100 MG', 'Obat Kaki', 55000, 3, 29),
(400, 'ADEM SARI JUMBO', ' 250 ml', 'CAIR', 25000, 4, 6),
(401, 'BETADINE OBAT KUMUR', ' 190 ml', 'TABLET', 23000, 4, 10),
(402, 'DEGIROL HISAP ', '0.25 mg', 'TABLET', 6500, 4, 11),
(403, 'LARUTAN KAKI TIGA ', '200 ml', 'CAIR', 4000, 4, 7),
(404, 'SP TROCHES MEIJI ', '0.5 mg', 'TABLET', 15000, 4, 8),
(405, 'STREPSIL COOL MENTHOL', '', 'TABLET', 12800, 4, 3),
(406, 'ALOCLAIR PLUS GEL', ' 8 ml', 'CAIR', 85000, 4, 11),
(407, 'TANTUM LOZENGES ', '', 'TABLET', 48500, 4, 18),
(408, 'JESSCOOL EFFERVESCENT', ' 3 mg', 'TABLET', 5000, 4, 31),
(409, 'LISTERINE COOL MINT ', '250 ml', 'CAIR', 18000, 4, 47),
(410, 'COOLING 5 PLUS ORANGE ', '', 'CAIR', 34000, 4, 50),
(411, 'TANTUM VERDE SOLUTION ', '', 'CAIR', 25000, 4, 11);

-- --------------------------------------------------------

--
-- Struktur dari tabel `struk`
--

CREATE TABLE `struk` (
  `id_struk` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  `id_obat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `struk`
--

INSERT INTO `struk` (`id_struk`, `username`, `tanggal`, `id_obat`) VALUES
(1, 'muhammadrohfi', '06-01-2021 11-14-42', 202),
(2, 'muhammadrohfi', '06-01-2021 11-14-42', 203);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`USERNAME`);

--
-- Indeks untuk tabel `bagianpenyakit`
--
ALTER TABLE `bagianpenyakit`
  ADD PRIMARY KEY (`ID_BagianPenyakit`);

--
-- Indeks untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`ID_OBAT`),
  ADD KEY `id_BagPenyakit` (`ID_BAGIANPENYAKIT`);

--
-- Indeks untuk tabel `struk`
--
ALTER TABLE `struk`
  ADD PRIMARY KEY (`id_struk`),
  ADD KEY `fk_username` (`username`),
  ADD KEY `fk_id_obat` (`id_obat`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `obat`
--
ALTER TABLE `obat`
  MODIFY `ID_OBAT` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=412;

--
-- AUTO_INCREMENT untuk tabel `struk`
--
ALTER TABLE `struk`
  MODIFY `id_struk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD CONSTRAINT `id_BagPenyakit` FOREIGN KEY (`ID_BAGIANPENYAKIT`) REFERENCES `bagianpenyakit` (`ID_BagianPenyakit`);

--
-- Ketidakleluasaan untuk tabel `struk`
--
ALTER TABLE `struk`
  ADD CONSTRAINT `fk_id_obat` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`ID_OBAT`),
  ADD CONSTRAINT `fk_username` FOREIGN KEY (`username`) REFERENCES `akun` (`USERNAME`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
